# ApplicationsPCB — where these prime-counting bounds are used

The two bounds proved here,

```
π(k) ≤ ⌈k/2⌉        and        π(k) ≤ 1 + ⌈k/3⌉,
```

are the first, most elementary members of the family of **upper bounds on the
prime counting function `π`**. They are the "warm-up" estimates that precede the
Chebyshev bounds and, ultimately, the Prime Number Theorem. Below we point to
where the bounds themselves, and the two techniques used to prove them (sieving
by residue classes, and parity/induction), appear in the literature.

> A note on scope. The *bounds* `π(k) ≤ ⌈k/2⌉` and `π(k) ≤ 1 + ⌈k/3⌉` and the
> two proof techniques are classical and standard; they are staple exercises in
> elementary number theory courses and textbooks. The specific *packaging* used
> here — the three named sets `UNO, DOS, TRES` and the two explicit "ways" — is a
> pedagogical presentation, not a named theorem, and we do not claim it as one.

## 1. Elementary residue-class sieves (Way I)

Counting the naturals that survive the removal of a few residue classes is the
starting point of sieve theory.

* Removing multiples of `2` gives `π(k) ≤ ⌈k/2⌉` (with the single correction for
  the prime `2`). Removing multiples of `2` and `3` — equivalently keeping only
  `n ≡ 1, 5 (mod 6)`, plus the primes `2, 3` — gives `π(k) ≤ 1 + ⌈k/3⌉`. This
  "`6k ± 1`" observation is standard; see G. H. Hardy and E. M. Wright,
  *An Introduction to the Theory of Numbers* (Oxford), and T. M. Apostol,
  *Introduction to Analytic Number Theory* (Springer).
* Continuing this process (removing multiples of `2, 3, 5, 7, …`) is exactly the
  **sieve of Eratosthenes** and, quantitatively, the **Legendre / Eratosthenes
  sieve** formula, which leads to the bound
  `π(k) = O(k · ∏_{p ≤ z}(1 - 1/p))` and to Mertens-type estimates. The two
  bounds here are the `z = 2` and `z = 3` cases of that idea.

## 2. Parity / "at most one prime per pair" (Way II)

The fact that among any two consecutive integers `> 2` at least one is composite
(one is even) is the combinatorial core of many elementary results.

* It underlies the observation that, apart from `(2,3)`, primes come no closer
  than the twin-prime spacing, and it is the base mechanism in elementary
  upper-bound sieves for **prime gaps** and for counting primes in short
  intervals.
* The `mod 3` refinement (a multiple of `3` bigger than `3` is composite, so
  `π(3(k+1)) = π(3k+2)`) is the same bookkeeping used when primes are organised
  by their residue **mod 6**, the setting for elementary discussions of
  **Dirichlet's theorem on primes in arithmetic progressions** for the modulus
  `6`.

## 3. Context: sharper prime-counting bounds

The bounds proved here are deliberately weak but unconditional and completely
elementary. They sit below the standard hierarchy:

* **Chebyshev's bounds** `c₁ k/log k ≤ π(k) ≤ c₂ k/log k`, proved from central
  binomial coefficient estimates (`C(2n,n) ≤ 4^n`), themselves formalised in
  Mathlib and used there for **Bertrand's postulate**
  (`Mathlib.NumberTheory.Bertrand`); see M. Aigner and G. M. Ziegler,
  *Proofs from THE BOOK* (Springer).
* The **Prime Number Theorem** `π(k) ∼ k/log k`, the asymptotic sharpening;
  see Apostol, *Introduction to Analytic Number Theory*.

In this hierarchy the present results are the "`k/2`" and "`k/3`" first steps:
they already show `π(k)/k → 0` cannot be read off (the bounds are linear), which
is exactly why the deeper `k/log k` estimates are needed — a standard motivating
remark in textbooks.

## 4. Formalisation context

* The prime counting function is available in Mathlib as `Nat.primeCounting`;
  the present development uses the equivalent explicit definition
  `#((Finset.Icc 1 k).filter Nat.Prime)` for direct control of the counting
  argument.
* The counting/complement technique (partitioning `Icc 1 k` by a decidable
  predicate and its negation) is the elementary combinatorial backbone that also
  appears in Mathlib's finite-set cardinality API
  (`Finset.card_filter_add_card_filter_not`, `Finset.card_union_of_disjoint`).

---

### References

* G. H. Hardy, E. M. Wright, *An Introduction to the Theory of Numbers* (Oxford)
  — elementary prime distribution, sieving, residue classes.
* T. M. Apostol, *Introduction to Analytic Number Theory* (Springer) — Chebyshev
  bounds, the Prime Number Theorem, primes in arithmetic progressions.
* M. Aigner, G. M. Ziegler, *Proofs from THE BOOK* (Springer) — Bertrand's
  postulate and central binomial coefficient estimates.
* The Lean **Mathlib** library, `Mathlib.NumberTheory.*` and `Mathlib.Data.Nat.*`
  — formalised prime-counting and finite-cardinality tools (the lemmas listed in
  `ExplainPCB.md`).
