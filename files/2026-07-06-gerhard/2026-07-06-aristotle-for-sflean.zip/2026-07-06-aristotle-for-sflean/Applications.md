# Applications — where these results are used in the literature

The five quantities studied here are not exotic: they are repackagings of the
two classical engines of elementary prime-counting theory —

* **products of primes (and prime powers) in a dyadic range**, and
* **central binomial coefficients and their `4^n`-type bounds**.

The comparisons proved in this project (`A ≤ B ≤ C ≤ E ≤ D`, up to the four
`{1,3,5,7}` exceptions) are exactly the inequalities one chains together in the
Chebyshev–Erdős circle of ideas. Below we point to where each ingredient
appears. We deliberately cite only standard, widely available sources.

> A note on scope. The *individual building blocks* (`A ∣ C`, `B ∣ C`,
> `C ≤ D`, `C ≤ E`, `E ≤ D`) are classical and heavily used, as documented
> below. The specific *packaging* used in the problem statement — the five
> named symbols `A,B,C,D,E`, and especially the iterated products
> `AA,BB,CC,DD,EE` along the repeated-halving chain `j_{i+1} = ⌈j_i/2⌉` — is a
> specialized construction; we are not aware of a standard named theorem for the
> iterated `DD/EE` comparison, and we do not claim one. Its interest is as an
> elementary but non-trivial consequence of the classical inequalities.

## 1. `A ∣ C` and `B ∣ C`: primes/prime-powers dividing binomial coefficients

The fact that the product of primes `p ∈ (n, 2n]` divides `C(2n, n)`, and more
generally that a prime power `p^e ≤ 2n` in the right range divides a central
binomial coefficient, is the heart of **Chebyshev's bounds**
`c₁·n/log n ≤ π(n) ≤ c₂·n/log n` and of **Erdős's proof of Bertrand's
postulate** (there is always a prime between `n` and `2n`).

* M. Aigner, G. M. Ziegler, *Proofs from THE BOOK* — the chapter on Bertrand's
  postulate uses precisely `A`-type products dividing `C(2n,n)`, together with
  the upper bound `C(2n,n) ≤ 4^n`.
* In Mathlib itself, these lemmas (`Nat.factorization_choose`,
  `Nat.centralBinom` factorization bounds) are the ones assembled to formalize
  **Bertrand's postulate** (`Mathlib.NumberTheory.Bertrand`).

The `B`-refinement (counting a prime once when *any* of its powers lies in the
window) is the tool for lower bounds on the **least common multiple**
`lcm(1,2,…,N)` and for **primorial**/Chebyshev-`ψ` estimates, where prime powers
— not just primes — must be accounted for.

## 2. `C ≤ D`: the central binomial upper bound `C(2n,n) ≤ 4^n`

This is one of the most reused inequalities in elementary number theory and
combinatorics:

* the upper half of **Chebyshev's theorem** and the classical proof that
  `∏_{p ≤ n} p ≤ 4^n` (bounds on the primorial);
* Erdős's proof that **`∑_p 1/p` diverges** and related estimates;
* countless textbook estimates for binomial sums and entropy bounds
  (`C(2n,n) ≈ 4^n/√(πn)`).

See Hardy & Wright, *An Introduction to the Theory of Numbers*, and Aigner &
Ziegler for representative uses.

## 3. `E ≤ D` and the reverse bound: sharpness of `C(2n,n)` vs `4^n`

The comparison of `E = C(2⌈k/2⌉, ⌈k/2⌉)` with `D = 4^⌊k/2⌋` is the quantitative
statement that central binomial coefficients are *close to but below* the
corresponding power of four. The two-sided estimate
`4^n/(2n+1) ≤ C(2n,n) ≤ 4^n` (Mathlib:
`Nat.four_pow_le_two_mul_add_one_mul_central_binom`, `Nat.choose_middle_le_pow`)
is the standard input to:

* Chebyshev-type lower bounds on `π(n)`;
* lower bounds on `lcm(1,…,n)` (e.g. `lcm(1,…,2n+1) ≥ 4^n`), themselves used in
  irrationality/complexity arguments;
* the analysis of **Wallis-type products** and Catalan numbers
  `C_n = C(2n,n)/(n+1)`.

The small exceptions `k ∈ {1,3,5,7}` reflect the familiar phenomenon that such
asymptotic inequalities only kick in past a small threshold.

## 4. `C ≤ E` (monotonicity) and the parity dichotomy

`C(k, ⌈k/2⌉) ≤ C(2⌈k/2⌉, ⌈k/2⌉)`, with equality iff `k` is even, is the
statement that the *widest* binomial coefficient in row `k` is at most the
central coefficient of the next even row. Row-monotonicity of binomial
coefficients toward the center is ubiquitous in combinatorics (unimodality of
binomial rows, Sperner-type extremal problems).

## 5. The halving chain `j_{i+1} = ⌈j_i/2⌉`

Repeated halving down to `1` is the recursion behind **divide-and-conquer**
recurrences and binary representations; telescoping products along such a chain
(as in `AA,…,EE`) is the elementary mechanism by which one turns a single-step
estimate (`X(k) ≤ Y(k)`) into a multiplicative bound across all scales. The
`DD/EE` result here is an instance where the naive factor-wise comparison
*fails* at a few small scales, and a global induction is needed to control the
finitely many exceptional chains — a useful cautionary example when telescoping
"almost monotone" quantities.

---

### References

* M. Aigner, G. M. Ziegler, *Proofs from THE BOOK* (Springer) — Bertrand's
  postulate; central binomial coefficient estimates.
* G. H. Hardy, E. M. Wright, *An Introduction to the Theory of Numbers*
  (Oxford) — Chebyshev's theorems, Legendre's formula, primorial bounds.
* The Lean **Mathlib** library, `Mathlib.NumberTheory.Bertrand` and
  `Mathlib.Data.Nat.Choose.*` — formalized versions of the above building blocks
  (the lemmas listed in `Explain.md`).
