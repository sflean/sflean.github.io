# ExplainLOA — step-by-step formal verification of the Laws Of Ademption

This document walks through **how the Laws Of Ademption (LOA) are verified in
Lean**, declaration by declaration. Everything lives in the `LOA` namespace and is
machine-checked in the Lean 4 project (with Mathlib). The development builds with
no `sorry`, and every final theorem uses only the standard axioms
(`propext`, `Classical.choice`, `Quot.sound`).

## The setting

We study a finite **arithmetic progression** with initial term `n + d`, common
difference `d`, and `k` terms:

```
n + d,  n + 2·d,  n + 3·d,  …,  n + k·d          (n, k, d : ℕ,  d ≥ 1,  gcd(n,d) = 1).
```

The `j`-th term is `n + j·d` for `1 ≤ j ≤ k`. When `d = 1` these are the `k`
consecutive integers `n+1, n+2, …, n+k`.

Two abbreviations, in `RequestProject/LOA/Defs.lean`:

```
LOA.apProd n d k = ∏_{j=1}^{k} (n + j·d)      -- product of all k terms
LOA.topProd n d k r = ∏_{j=k-r+1}^{k} (n + j·d) -- product of the r largest terms
                    = ∏_{i=1}^{r} (n + (k+1-i)·d)
```

Auxiliary positivity facts: `term_pos` (each term `n + j·d > 0` for `1 ≤ j`,
`1 ≤ d`), `apProd_pos`, `apProd_ne_zero`.

Throughout we use the `p`-adic valuation `v_p(m)`, which in Mathlib is
`m.factorization p` (a `Finsupp` evaluated at the prime `p`). The two facts we
lean on constantly are:

* `p^(v_p(m)) ∣ m` (Mathlib: `Nat.ordProj_dvd`), and
* for `m ≠ 0`, `p^a ∣ m ↔ a ≤ v_p(m)` (Mathlib:
  `Nat.Prime.pow_dvd_iff_le_factorization`).

Files:

* `RequestProject/LOA/Defs.lean` — definitions and positivity.
* `RequestProject/LOA/Basic.lean` — the basic result.
* `RequestProject/LOA/Erdos.lean` — LOA Erdős.
* `RequestProject/LOA/ELOA.lean` — the three extended laws.
* `RequestProject/LOA/Main.lean` — a top-level index.

---

## 1. The basic result (`Basic.lean`)

**Statement (valuation form).** Let `p` be a prime with `p ∤ d`. Among the `k`
terms choose one, `n + i·d` (`1 ≤ i ≤ k`), of **maximal** `p`-adic valuation. Then

```
v_p( ∏_{j=1}^k (n + j·d) )  ≤  v_p((k-1)!)  +  v_p(n + i·d).
```

Equivalently, writing `p^e = p^{v_p(n+i·d)}` for the largest prime power of `p`
dividing any single term and `p^f = [(k-1)!]_p = p^{v_p((k-1)!)}` for the exact
power of `p` in `(k-1)!`: if `p^g ∣ ∏ (n+j·d)` then `p^g ∣ p^{e+f} = [(k-1)!]_p ·
(n + i·d)`.

In Lean:

```lean
theorem LOA.basic {p n d k : ℕ} (hp : p.Prime) (hpd : ¬ p ∣ d) (hk : 1 ≤ k)
    {i : ℕ} (hi : i ∈ Finset.Icc 1 k)
    (hmax : ∀ j ∈ Finset.Icc 1 k,
      (n + j*d).factorization p ≤ (n + i*d).factorization p) :
    (apProd n d k).factorization p
      ≤ (Nat.factorial (k-1)).factorization p + (n + i*d).factorization p
```

**Why `p ∤ d` is the right hypothesis.** If instead `p ∣ d`, then because
`gcd(n,d) = 1` no term `n + j·d` is divisible by `p` at all (a common factor of a
term and of `d` would divide `n`). So the interesting case is `p ∤ d`, and the
basic result is stated exactly there; the `p ∣ d` case is folded into the
consequences.

**The proof.** It is a clean valuation count in three moves.

1. **Product ↦ sum of valuations.** Since every term is nonzero,
   `Nat.factorization_prod` gives
   `v_p(∏_{j=1}^k (n+j·d)) = ∑_{j=1}^k v_p(n+j·d)`.
   We split off the maximal term `j = i`
   (`Finset.sum_eq_add_sum_diff_singleton`).

2. **The ultrametric step** (`LOA.factorization_le_of_two_terms`). For any two
   term indices `a < b` with `v_p(n+a·d) ≤ v_p(n+b·d)`,
   ```
   v_p(n + a·d)  ≤  v_p(b - a).
   ```
   Reason: put `m = v_p(n+a·d)`. Then `p^m ∣ n+a·d` (`Nat.ordProj_dvd`) and,
   because `m ≤ v_p(n+b·d)`, also `p^m ∣ n+b·d`
   (`Nat.Prime.pow_dvd_iff_le_factorization`). Subtracting (`Nat.dvd_sub`),
   `p^m ∣ (n+b·d) - (n+a·d) = (b-a)·d`. Since `p ∤ d`, `p^m` is coprime to `d`
   (`Nat.Prime.coprime_iff_not_dvd`, `Nat.Coprime.pow_left`), so
   `p^m ∣ (b - a)` (`Nat.Coprime.dvd_of_dvd_mul_right`), i.e.
   `m ≤ v_p(b - a)` (`Nat.pow_succ_factorization_not_dvd`).
   Applied to every `j ≠ i` (with `hmax` supplying the valuation comparison), this
   bounds `v_p(n+j·d)` by `v_p(|i - j|)`.

3. **Summing the differences.** As `j` runs over `{1,…,k} \ {i}`, the differences
   `|i - j|` run exactly over `1,…,i-1` and `1,…,k-i`. Hence
   ```
   ∑_{j≠i} v_p(|i-j|) = v_p((i-1)!) + v_p((k-i)!),
   ```
   using `LOA.sum_factorization_Icc` (`∑_{a=1}^m v_p(a) = v_p(m!)`, from
   `Nat.factorization_prod` applied to `m! = ∏_{a=1}^m a`). Finally
   `(i-1)! · (k-i)! ∣ (k-1)!` because `(i-1) + (k-i) = k-1`
   (`Nat.factorial_mul_factorial_dvd_factorial_add`), so
   `v_p((i-1)!) + v_p((k-i)!) = v_p((i-1)!·(k-i)!) ≤ v_p((k-1)!)`
   (`Nat.factorization_mul`, `Nat.factorization_le_iff_dvd`).

Adding the maximal term back gives the bound. A packaged existence version,
`LOA.basic_exists`, produces the argmax index `i` automatically via
`Finset.exists_max_image` on the nonempty `Finset.Icc 1 k`.

---

## 2. LOA Erdős (`Erdos.lean`)

**Statement.** If `p` is prime and `p^e ∣ C(n+k, k)` and `0 < n+k`, then
`p^e ≤ n + k`.

```lean
theorem LOA.LOA_Erdos {p e n k : ℕ} (hp : p.Prime) (hnk : 0 < n + k)
    (hdvd : p ^ e ∣ (n + k).choose k) : p ^ e ≤ n + k
```

*Faithfulness note.* The classical Erdős statement is about **prime** powers; for
composite `p` it is false (e.g. `6 ∣ C(4,2) = 6` but `6 > 4`), so `p.Prime` is
kept. The only genuinely excluded case is `n = k = 0` (where `C(0,0)=1` but
`n+k=0`); the mild hypothesis `0 < n+k` rules exactly this out.

**The proof.** Take `d = 1`, so the terms are `n+1,…,n+k` and `gcd(n,1)=1` is
automatic. The key identity (`LOA.apProd_one_eq_choose_mul_factorial`) is

```
apProd n 1 k = ∏_{j=1}^k (n+j) = C(n+k,k) · k!
```

(proved via `Nat.descFactorial_eq_factorial_mul_choose`). Comparing `p`-adic
valuations (`Nat.factorization_mul`) turns the basic result into

```
v_p(C(n+k,k)) + v_p(k!)  =  v_p(∏(n+j))  ≤  v_p((k-1)!) + v_p(n+i)
```

for a maximal term `n+i` (from `basic_exists`). Since `k! = k·(k-1)!`, we have
`v_p(k!) ≥ v_p((k-1)!)`, so `v_p(C(n+k,k)) ≤ v_p(n+i)`. Now `p^e ∣ C(n+k,k)` gives
`e ≤ v_p(C(n+k,k)) ≤ v_p(n+i)`, hence `p^e ∣ p^{v_p(n+i)} ∣ (n+i)`
(`Nat.ordProj_dvd`), so `p^e ≤ n+i ≤ n+k` (`Nat.le_of_dvd`). The edge cases
`e=0` and `k=0` are handled directly.

---

## 3. The extended laws (`ELOA.lean`)

All three extended laws start from the **per-prime consequence** of the basic
result.

### 3.0 Building blocks

* `LOA.prod_primePow_dvd` — a product `∏_{p∈P} p^{E p}` over **distinct** primes,
  each factor dividing `m`, itself divides `m`. Proof by induction on `P`: distinct
  primes are coprime (`Nat.Coprime.pow`, `Nat.Coprime.prod_right`) and
  `Nat.Coprime.mul_dvd_of_dvd_of_dvd` glues the factors.

* `LOA.per_prime` / `LOA.per_prime_full` — if `p^e ∣ ∏(n+j·d)` then there is a
  `p`-adic argmax index `i ∈ {1,…,k}` with `e ≤ v_p((k-1)!) + v_p(n+i·d)`. Proof:
  if `p ∣ d` then (by `gcd(n,d)=1`) `p` divides no term, forcing `e = 0`, trivial;
  otherwise `p ∤ d`, and `basic_exists` plus `e ≤ v_p(∏)` give the bound.
  `per_prime_full` additionally returns the argmax property (needed for the LCM
  form).

* `LOA.prod_subset_le_topBlock` — the **rearrangement lemma**: for `I ⊆ {1,…,k}`,
  ```
  ∏_{t∈I} (n + t·d)  ≤  ∏_{t=k-#I+1}^{k} (n + t·d),
  ```
  i.e. any `#I` terms are dominated by the `#I` **largest** terms. Proof by
  strong induction on `k`: peel off the maximum `M` of `I` (which is `≤ k`), send
  it to the top index `k`, and apply the induction hypothesis to `I \ {M} ⊆
  {1,…,k-1}` (`Finset.mul_prod_erase`, `Finset.prod_Ico_succ_top`, monotonicity of
  `t ↦ n + t·d`).

* `LOA.prodPow_le_topProd` — the **grouping crux**: given for each prime `p ∈ P`
  an index `J p ∈ {1,…,k}` and a power `p^{E p}` dividing the term `n + (J p)·d`,
  ```
  ∏_{p∈P} p^{E p}  ≤  topProd n d k #P.
  ```
  Proof: group the primes by the term they are assigned to
  (`Finset.prod_fiberwise_of_maps_to`). Within each fiber the prime powers are
  coprime, so their product divides that single term (`prod_primePow_dvd`), hence
  is `≤` it. Multiplying over the (at most `#P`) distinct terms used and applying
  `prod_subset_le_topBlock` (and `Finset.prod_le_prod_of_subset_of_one_le'` to pad
  up to `#P` largest terms) gives the bound.

### 3.1 ELOA Principal Lemma (`LOA.principal`)

**Statement.** For distinct primes `P` with `#P < k`, `gcd(n,d)=1`, `d ≥ 1`, if
`∏_{p∈P} p^{e p} ∣ ∏_{j=1}^k (n+j·d)` then

```
∏_{p∈P} p^{e p}  ≤  (k-1)! · ∏_{i=1}^{#P} (n + (k+1-i)·d)  =  (k-1)! · topProd n d k #P.
```

**The proof.** For each `p ∈ P`, `per_prime` gives an argmax index `J p` with
`e p ≤ v_p((k-1)!) + E p`, where `E p = v_p(n + (J p)·d)` and `p^{E p} ∣ n+(J p)·d`.
Therefore, factorwise,

```
∏ p^{e p}  ≤  ∏ p^{v_p((k-1)!) + E p}  =  (∏ p^{v_p((k-1)!)}) · (∏ p^{E p})
```

(`Finset.prod_le_prod'`, `pow_add`, `Finset.prod_mul_distrib`). The first factor
divides `(k-1)!` (`prod_primePow_dvd` with `Nat.ordProj_dvd`), so it is `≤ (k-1)!`.
The second factor is `≤ topProd n d k #P` by the grouping crux. Multiplying the two
bounds (`Nat.mul_le_mul`) finishes.

### 3.2 ELOA for `d = 1` (`LOA.eloa_d1`)

**Statement.** With `d = 1`,

```
∏_{p∈P} p^{e p}  ≤  k! · ∏_{i=1}^{#P} (n + k + 1 - i).
```

**The proof.** Immediate from `principal` at `d = 1`: `topProd n 1 k #P` reindexes
(`Finset.prod_bij`, `i ↦ k+1-i`) to `∏_{i=1}^{#P} (n+k+1-i)`, and
`(k-1)! ≤ k!` (`Nat.factorial_le`) weakens the constant. This matches the user's
`k!` form (a weaker but cleaner constant than the sharp `(k-1)!` of the Principal
Lemma).

### 3.3 ELOA for LCM (`LOA.eloa_lcm`)

**Statement.** For distinct primes `P` with `#P < k`, `gcd(n,d)=1`, `d ≥ 1`, and
each `p^{e p} ∣ ∏(n+j·d)`, there are `p`-adic argmax indices `J p ∈ {1,…,k}` with

```
lcm_{p∈P} p^{e p}  ≤  (lcm_{p∈P} [(k-1)!]_p) · (lcm_{p∈P} (n + (J p)·d)),
```

where `[(k-1)!]_p = p^{v_p((k-1)!)}`.

**The proof.** This form needs **no** rearrangement — it is pure divisibility.
Choose `J` from `per_prime_full`. Write `A = lcm_{p} p^{v_p((k-1)!)}` and
`B = lcm_{p} (n + (J p)·d)`. For each `p ∈ P`:

* `p^{e p} ∣ p^{v_p((k-1)!) + E p} = p^{v_p((k-1)!)} · p^{E p}` (from `per_prime_full`);
* `p^{v_p((k-1)!)} ∣ A` and `n+(J p)·d ∣ B` (`Finset.dvd_lcm`), while
  `p^{E p} ∣ n+(J p)·d` (`Nat.ordProj_dvd`), so `p^{E p} ∣ B`;
* hence `p^{e p} ∣ A · B` (`mul_dvd_mul`).

By `Finset.lcm_dvd`, `lcm_{p} p^{e p} ∣ A · B`; both `A, B` are nonzero
(`Finset.lcm_eq_zero_iff`, each entry positive), so `A·B > 0` and
`Nat.le_of_dvd` gives the inequality. The `#P < k` hypothesis is part of the
stated law but is not needed for the LCM form, so it appears as `_hr`.

*Remark.* Because the primes in `P` are distinct, `lcm_{p∈P} p^{e p}` equals the
product `∏_{p∈P} p^{e p}`, and likewise for the `[(k-1)!]_p`; the LCM form and the
product (Principal) form are two faces of the same per-prime bound.

---

## Bibliography

### Mathlib lemmas and tactics used

Valuations / factorization:

* `Nat.factorization_prod` — factorization of a finite product is the sum of
  factorizations.
* `Nat.factorization_mul` — `v_p(a·b) = v_p(a) + v_p(b)` for `a,b ≠ 0`.
* `Nat.factorization_le_iff_dvd` — `d.factorization ≤ n.factorization ↔ d ∣ n`.
* `Nat.Prime.pow_dvd_iff_le_factorization` — `p^a ∣ n ↔ a ≤ v_p(n)` (`n ≠ 0`).
* `Nat.ordProj_dvd` — `p^{v_p(n)} ∣ n`.
* `Nat.pow_succ_factorization_not_dvd` — `p^{v_p(n)+1} ∤ n` (`n ≠ 0`).
* `Nat.factorization_eq_zero_of_not_dvd` — `p ∤ n → v_p(n) = 0`.

Divisibility / coprimality:

* `Nat.dvd_sub` — divisibility is preserved by subtraction.
* `Nat.Prime.coprime_iff_not_dvd`, `Nat.Coprime.pow_left`, `Nat.Coprime.pow`,
  `Nat.Coprime.prod_right` — coprimality of prime powers.
* `Nat.Coprime.dvd_of_dvd_mul_right`, `Nat.Coprime.mul_dvd_of_dvd_of_dvd` — cancel
  a coprime factor / glue coprime divisors.
* `Nat.le_of_dvd` — a positive multiple bounds its divisor.

Factorials / binomials:

* `Nat.factorial_mul_factorial_dvd_factorial_add` — `a!·b! ∣ (a+b)!`.
* `Nat.factorial_dvd_factorial`, `Nat.factorial_le` — monotonicity of `n!`.
* `Nat.descFactorial_eq_factorial_mul_choose`,
  `Nat.choose_mul_factorial_mul_factorial` — the `C(n+k,k)·k! = ∏(n+j)` identity.

Finset combinatorics:

* `Nat.factorization_prod`, `Finset.prod_range_add_one_eq_factorial` — `m!` as a
  product.
* `Finset.exists_max_image` — existence of an argmax over a nonempty finset.
* `Finset.sum_eq_add_sum_diff_singleton`, `Finset.mul_prod_erase` — peeling an
  element.
* `Finset.prod_bij`, `Finset.prod_fiberwise_of_maps_to` — reindexing / grouping.
* `Finset.prod_le_prod'`, `Finset.prod_le_prod_of_subset_of_one_le'`,
  `Finset.prod_Ico_succ_top` — monotone products over finsets.
* `Finset.dvd_lcm`, `Finset.lcm_dvd`, `Finset.lcm_eq_zero_iff` — the finset lcm.

Tactics: `omega`, `linarith`, `nlinarith`, `positivity`, `simp`/`simp_all`,
`aesop`, `grind`, `induction`, `convert`.

### Background sources (internet / literature)

* **Kummer's theorem** on the `p`-adic valuation of binomial coefficients
  (`v_p C(m+n, n)` = number of carries when adding `m` and `n` in base `p`).
  See the Wikipedia article "Kummer's theorem".
* **P. Erdős**, *A theorem of Sylvester and Schur*, J. London Math. Soc. **9**
  (1934), 282–288 — the setting in which the "largest prime power dividing a
  binomial coefficient is at most `n+k`" statement (LOA Erdős) is classical.
* **J. J. Sylvester** (1892) and **I. Schur**: the Sylvester–Schur theorem on
  prime factors of products of consecutive integers — the `d = 1` background of the
  extended laws.
* General references for `p`-adic valuations, Legendre's formula, and products of
  terms in arithmetic progression: any standard elementary number theory text
  (e.g. Hardy & Wright, *An Introduction to the Theory of Numbers*).
