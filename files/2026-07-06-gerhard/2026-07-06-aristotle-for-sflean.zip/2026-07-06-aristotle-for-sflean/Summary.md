# Summary

This project settles, and formally verifies in Lean 4 (with Mathlib), **every**
pairwise comparison between the five quantities

| symbol | definition |
|---|---|
| `A(k)` | product of the primes `p` with `⌈k/2⌉ < p ≤ k` |
| `B(k)` | product of the *distinct* primes `p` such that some power `p^e` (`e ≥ 1`) satisfies `⌈k/2⌉ < p^e ≤ k` |
| `C(k)` | `C(k, ⌈k/2⌉)` (a central binomial coefficient) |
| `D(k)` | `4^(k − ⌈k/2⌉) = 4^⌊k/2⌋` |
| `E(k)` | `C(2⌈k/2⌉, ⌈k/2⌉)` |

and between their iterated products `AA, BB, CC, DD, EE` taken along the halving
chain `j₀ = k`, `j_{i+1} = ⌈j_i/2⌉`.

Throughout we write `h(k) = ⌈k/2⌉` (in Lean, `hc k = (k+1)/2`), so that
`k − h(k) = ⌊k/2⌋`.

## The answer in one picture

For every `k` the five numbers are linearly ordered (no pair is ever
*incomparable*):

```
A(k) ≤ B(k) ≤ C(k) ≤ E(k)        and        C(k) ≤ D(k),
```

together with the single "wobbly" relation between `D` and `E`:

```
E(k) ≤ D(k)   for all k except k ∈ {1, 3, 5, 7},   where instead  D(k) < E(k).
```

So, apart from the four small exceptions, the full order is

```
A(k) ≤ B(k) ≤ C(k) ≤ E(k) ≤ D(k).
```

The exceptions are genuinely tiny: at `k = 1,3,5,7` the number `E(k)` overshoots
`4^⌊k/2⌋` because the central binomial coefficient `C(2n,n)` is not yet small
compared with `4^{n-1}`.

## Intuition behind each comparison

* **`A ≤ B`.** The primes counted by `A` (those with `h(k) < p ≤ k`) are exactly
  the `e = 1` members of the larger family counted by `B`. `B` multiplies over a
  *superset* of primes, so it can only grow.

* **`A ≤ C` and `B ≤ C` (in fact `A ∣ C` and `B ∣ C`).** A prime `p` with
  `h(k) < p ≤ k` divides `C(k, h(k))` exactly once (it appears in the numerator
  `k!` but is too big to appear in `h(k)!` or `(k−h(k))!`). More generally, if a
  *power* `p^e` lands in `(h(k), k]`, then adding `h(k)` and `k − h(k)` in base
  `p` produces a carry at digit `e` (both summands are `< p^e` but their sum
  `k ≥ p^e`), so by Kummer/Legendre `p` divides `C(k, h(k))`. Distinct primes are
  coprime, so their product divides `C(k, h(k))`, hence is `≤ C(k)`.

* **`C ≤ D`.** With `n = ⌊k/2⌋`, symmetry gives `C(k) = C(k, n)`, and since
  `k ≤ 2n+1`, monotonicity plus the classical bound `C(2n+1, n) ≤ 4^n` give
  `C(k) ≤ 4^n = D(k)`.

* **`C ≤ E`, with equality iff `k` is even.** `C(k) = C(k, h(k))` and
  `E(k) = C(2h(k), h(k))`; since `k ≤ 2h(k)`, the top index only grows, so
  `C ≤ E`. When `k` is even, `k = 2h(k)` and the two are literally equal; when
  `k` is odd, `k < 2h(k)` and the inequality is strict.

* **`E ≤ D` except `{1,3,5,7}`.** For even `k`, `E(k) = C(2m,m) ≤ 4^m = D(k)`
  is the plain central-binomial bound. For odd `k = 2m+1` with `m ≥ 4`
  (i.e. `k ≥ 9`), one needs the sharper `C(2n,n) ≤ 4^{n-1}` for `n ≥ 5`, proved
  by an easy induction from the recurrence
  `(n+1)·C(2n+2,n+1) = 2(2n+1)·C(2n,n)` (the growth factor `2(2n+1)/(n+1) < 4`).
  The four odd values `k = 1,3,5,7` fall below this threshold and are the true
  exceptions.

## The iterated products

Every single-index inequality holds for *all* indices, so the corresponding
product inequalities hold factor-by-factor for all `k, r`:

```
AA ≤ BB ≤ CC ≤ DD,   AA ≤ BB ≤ CC ≤ EE,   CC ≤ DD,   CC ≤ EE,
```

and `CC(k,r) = EE(k,r)` iff every chain element `j_0, …, j_{r-1}` is even.

The only product comparison that is not decided factor-by-factor is **`DD` vs
`EE`**, because `D(j) < E(j)` for `j ∈ {3,5,7}`. The result, matching the
requested template, is:

> For all `k` and `r` with `j_r > 1`, `EE(k,r) ≤ DD(k,r)`, **except** for the
> seven pairs
> `(k,r) ∈ {(3,1),(5,1),(5,2),(7,1),(9,2),(9,3),(17,4)}`,
> where `DD(k,r) < EE(k,r)`.

The proof is a strong induction on `k`: peeling the first chain factor gives
`DD(k,r+1) = D(k)·DD(h(k),r)` and `EE(k,r+1) = E(k)·EE(h(k),r)`. For `k ≥ 35`
the head factor `D(k) ≥ E(k)` and the tail is handled by induction (`h(k) ≥ 18`
can never start an exceptional sub-chain). For `k ≤ 34` the validity constraint
`j_r > 1` bounds `r ≤ 5`, so the statement reduces to a finite, machine-checked
computation, which pins down exactly the seven exceptional pairs.

See `Explain.md` for the detailed, step-by-step verification and the
bibliography of Mathlib lemmas used, and `Applications.md` for where these
building blocks appear in the literature.

## Heuristic bounds on `n` for `k = 2 … 1000` (linear `n ≈ 3k + O(√k)`)

Building on the follow-on work (Step 1, Step 2, Lemma 1, Lemma 2 in the *main*
project), iterating Lemma 1 + Lemma 2 down the halving chain `⌈k/2^r⌉` turns the
quadratic bounds into a **linear** one: assuming `∏_{i=1}^{k}(n+i)` is
`k`-smooth,

> `n + k < 4k + 2·√k + O(1)`,  equivalently  `n < 3k + 2·√k + O(1)`.

This is a **heuristic** extrapolated from an explicit `#eval` computation for
`k = 2 … 1000` (e.g. `k = 1000` gives `n+k < 4032`, `n < 3032`), not a formal
proof. The full write-up — the mechanism, the representative table, and the
empirical envelope `boundNK(k) ≤ 4k + 2.14·√k` — is in the
**"Heuristic bounds on `n` for `k = 2 … 1000`"** section of `SummaryMain.md`, and
the reproducible computation is `RequestProject/Heuristic.lean`.
