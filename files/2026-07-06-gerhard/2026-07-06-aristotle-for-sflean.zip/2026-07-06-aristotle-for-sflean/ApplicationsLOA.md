# ApplicationsLOA — where the Laws Of Ademption are used

The basic result formalised here bounds the `p`-adic valuation of a product of
terms in arithmetic progression:

```
v_p( ∏_{j=1}^k (n + j·d) )  ≤  v_p((k-1)!) + (largest v_p of a single term),   (p ∤ d).
```

Its consequences (LOA Erdős, and the ELOA product/LCM forms) are, in essence, the
statements that the "extra" prime-power content of `∏(n+j·d)` beyond a single term
is controlled by `(k-1)!`. This circle of ideas is classical and recurs across
elementary and analytic number theory. Below we point to where the results and the
technique are used.

> A note on scope and naming. The valuation bound and its use to control prime
> powers in products of consecutive integers / binomial coefficients are
> **classical**. The specific label "Laws Of Ademption" and the exact packaging
> (`AA`-style enumerations, the four named ELOA variants) are the user's
> presentation; we do not attribute that naming to a specific published source,
> and we cite only the classical results and techniques that the proofs rely on.

## 1. Prime powers in binomial coefficients (LOA Erdős)

The statement "if `p^e ∣ C(n+k, k)` then `p^e ≤ n+k`" is a cornerstone of
elementary number theory.

* **Kummer's theorem** (1852) computes `v_p C(m+n, n)` exactly as the number of
  carries in adding `m` and `n` in base `p`; a direct corollary is that the
  largest prime power dividing `C(m, r)` is at most `m`. This is the sharpest form
  of LOA Erdős. (Wikipedia: "Kummer's theorem".)
* **Legendre's formula** for `v_p(n!)` is the computational backbone behind both
  Kummer's theorem and the factorial term `(k-1)!` in the basic result.
* **Erdős's proof of Bertrand's postulate** (1932) is built precisely on bounding
  the prime powers that divide the central binomial coefficient `C(2n, n)` — every
  prime power `p^e ∣ C(2n,n)` satisfies `p^e ≤ 2n`. LOA Erdős is exactly this kind
  of bound. (Wikipedia: "Proof of Bertrand's postulate".)
* The same bound underlies **Chebyshev-type estimates** `π(x) ≍ x/log x` and the
  elementary theory of the primorial and `lcm(1,…,n)`.

## 2. Products of consecutive integers and the Sylvester–Schur theorem (ELOA, `d = 1`)

The `d = 1` extended law concerns `∏_{j=1}^k (n+j) = (n+1)(n+2)…(n+k)`.

* **Sylvester–Schur theorem** (Sylvester 1892; Schur; Erdős 1934): a product of
  `k` consecutive integers each `> k` has a prime factor `> k`. Erdős's 1934 proof
  (*A theorem of Sylvester and Schur*, J. London Math. Soc. **9**, 282–288) rests
  on estimating how prime powers distribute across the `k` terms — the same
  bookkeeping as the basic result here.
* Bounds of the shape "`∏ p_i^{e_i} ≤ k! · (product of the largest terms)`"
  (the ELOA Principal Lemma / `d=1` form) are exactly the inequalities used to
  show that the "smooth part" of `(n+1)…(n+k)` cannot be too large, forcing the
  existence of large prime factors.

## 3. Arithmetic progressions with `d > 1` (ELOA general `d`, LCM form)

Replacing consecutive integers by a general progression `n+d, …, n+kd` with
`gcd(n,d)=1` is the setting of a large body of work generalising Sylvester–Schur.

* **Generalised Sylvester–Erdős / Sylvester–Schur for arithmetic progressions:**
  the study of the greatest prime factor and of prime powers dividing
  `∏_{j=1}^k (n+j·d)` is the subject of many papers by **T. N. Shorey**,
  **N. Saradha**, and collaborators (results on `P(∏(n+j·d))` and on when such a
  product can be a perfect power). The per-prime valuation bound (basic result) and
  the LCM/product packaging are the standard first step in that literature.
* The **LCM form** connects to estimates for `lcm` of terms of an arithmetic
  progression, a quantity studied in analytic number theory (generalising
  `lcm(1,…,n) = e^{ψ(n)}`, with `ψ` the Chebyshev function).

## 4. Techniques exercised here (reusable)

Independently of the specific laws, the formal development packages several
reusable pieces:

* the **ultrametric comparison** of two terms of a progression via their difference
  (`LOA.factorization_le_of_two_terms`);
* the **valuation of a factorial as a sum of term-valuations**
  (`LOA.sum_factorization_Icc`);
* a **rearrangement lemma** — any `m` terms of a monotone family are dominated by
  the `m` largest (`LOA.prod_subset_le_topBlock`);
* a **coprime grouping crux** — distinct-prime prime powers dividing terms are,
  grouped by term, bounded by the largest terms (`LOA.prodPow_le_topProd`);
* `∏` over distinct primes of prime powers dividing `m` divides `m`
  (`LOA.prod_primePow_dvd`).

These are exactly the lemmas one reaches for when formalising Kummer's theorem,
Bertrand's postulate, or Sylvester–Schur-type results, and they are stated
generically so they can be reused.

## References

* E. E. Kummer, *Über die Ergänzungssätze zu den allgemeinen
  Reciprocitätsgesetzen*, J. Reine Angew. Math. **44** (1852). (See "Kummer's
  theorem".)
* A.-M. Legendre, *Essai sur la théorie des nombres* (Legendre's formula for
  `v_p(n!)`).
* P. Erdős, *A theorem of Sylvester and Schur*, J. London Math. Soc. **9** (1934),
  282–288.
* P. Erdős, *Beweis eines Satzes von Tschebyschef*, Acta Sci. Math. (Szeged) **5**
  (1932), 194–198 (elementary proof of Bertrand's postulate).
* J. J. Sylvester, *On arithmetical series*, Messenger of Math. **21** (1892).
* T. N. Shorey and R. Tijdeman, *Exponential Diophantine Equations*, Cambridge
  Univ. Press (1986) — background on prime factors of products of terms in
  arithmetic progression.
* G. H. Hardy and E. M. Wright, *An Introduction to the Theory of Numbers*
  (general background on `p`-adic valuations and Legendre's formula).
