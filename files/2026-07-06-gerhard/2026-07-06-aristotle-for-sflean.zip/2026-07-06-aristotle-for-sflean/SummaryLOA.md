# SummaryLOA — the Laws Of Ademption, main steps and intuition

This project formally verifies, in Lean 4 (with Mathlib), a **basic result** on
arithmetic progressions and the four **Laws Of Ademption** that follow from it.
Everything builds with no `sorry`, and every final theorem relies only on the
standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

## The object of study

Fix natural numbers `n, k, d` with `d ≥ 1` and `gcd(n, d) = 1`, and look at the
`k` terms of the arithmetic progression

```
n + d,  n + 2·d,  …,  n + k·d.
```

When `d = 1` these are the consecutive integers `n+1, …, n+k`. We write
`v_p(m)` for the exponent of the prime `p` in `m`, `[(k-1)!]_p = p^{v_p((k-1)!)}`
for the exact power of `p` in `(k-1)!`, and

```
apProd n d k  = ∏_{j=1}^{k} (n + j·d)        (the product of all k terms).
```

## The basic result — one idea, phrased two ways

**Valuation form.** Fix a prime `p` that does not divide `d`. Among the `k` terms
let `n + i·d` have the **largest** power of `p`, say `p^e`. Then the power of `p`
in the whole product is at most `e` plus the power of `p` in `(k-1)!`:

```
v_p(apProd n d k)  ≤  v_p((k-1)!) + e.
```

**Divisibility form.** If `p^g ∣ apProd n d k`, then `p^g ∣ [(k-1)!]_p · (n+i·d)`.
The extra factor `[(k-1)!]_p` is "borrowed" (*ademption* = a taking-away) from the
factorial, and `(n+i·d)` is the single most `p`-divisible term.

### Why it is true (intuition)

Pick the most `p`-divisible term, `n + i·d`. For **every other** term `n + j·d`,
compare it with the champion: their difference is `(j-i)·d`, and since `p ∤ d` the
power of `p` in the difference is exactly the power of `p` in `j - i`. The
ultrametric ("non-Archimedean") inequality then forces

```
v_p(n + j·d)  ≤  v_p(j - i).
```

So the whole product carries no more `p` than the champion term contributes,
**plus** what the differences `j - i` contribute. But as `j` ranges over the other
`k-1` indices, the numbers `|i - j|` are exactly `1, …, i-1` and `1, …, k-i`,
whose product is `(i-1)!·(k-i)!` — a divisor of `(k-1)!`. Summarising the `p`-powers:

```
v_p(apProd)  ≤  e  +  v_p((i-1)!) + v_p((k-i)!)  ≤  e + v_p((k-1)!).
```

That is the whole proof: **one champion term + a factorial's worth of
differences.**

## The four Laws Of Ademption

Each law reads off the basic result and packages it for many primes at once. In
all of them `P` is a set of **distinct primes** with `#P < k`, and exponents are
allowed to be `0` (so `P` may even contain primes that do not divide the product —
they contribute a harmless factor `1`).

1. **LOA Erdős.** If `p` is prime and `p^e ∣ C(n+k, k)` (with `n+k > 0`) then
   `p^e ≤ n + k`.
   *Intuition:* `C(n+k,k)·k! = (n+1)…(n+k)`, so the `p`-part of the binomial
   coefficient is bounded by the `p`-part of a single term `n+i ≤ n+k`; the
   factorial `(k-1)!` borrowed by the basic result is absorbed by `k!` in the
   denominator.

2. **ELOA Principal Lemma (general `d`).** If `∏_{p∈P} p^{e_p} ∣ ∏_{j=1}^k (n+j·d)`,
   then
   ```
   ∏_{p∈P} p^{e_p}  ≤  (k-1)! · ∏_{i=1}^{#P} (n + (k+1-i)·d),
   ```
   the product of the `#P` **largest** terms times `(k-1)!`.
   *Intuition:* per prime, `p^{e_p} ≤ [(k-1)!]_p · p^{E_p}`. Multiplying, the
   `[(k-1)!]_p` factors (distinct primes!) reassemble into a divisor of `(k-1)!`,
   while the champion prime powers `p^{E_p}` — each dividing some term — are, when
   grouped by the term they divide, bounded by the largest terms.

3. **ELOA for `d = 1`.** With `d = 1` (consecutive integers),
   ```
   ∏_{p∈P} p^{e_p}  ≤  k! · ∏_{i=1}^{#P} (n + k + 1 - i).
   ```
   This is the Principal Lemma at `d = 1`, with the slightly weaker but cleaner
   constant `k!` in place of `(k-1)!`.

4. **ELOA for LCM (general `d`).**
   ```
   lcm_{p∈P} p^{e_p}  ≤  (lcm_{p∈P} [(k-1)!]_p) · (lcm_{p∈P} (n + j_p·d)),
   ```
   where `n + j_p·d` is a term with the largest power of `p`.
   *Intuition:* the cleanest packaging — no rearrangement is needed, only the
   per-prime bound `p^{e_p} ∣ [(k-1)!]_p · (n + j_p·d)` and the fact that each
   factor divides the corresponding lcm.

## Design of the formal proof

* The **basic result** (`LOA.basic`) is proved once, as a valuation count. A
  packaged existence version (`LOA.basic_exists`) produces the champion index.
* A **per-prime consequence** (`LOA.per_prime`, `LOA.per_prime_full`) restates it
  as `e ≤ v_p((k-1)!) + v_p(n + i·d)`, handling the `p ∣ d` case (where `p`
  divides no term) uniformly.
* Two combinatorial helpers do the heavy lifting for the product form: a
  **rearrangement lemma** (`LOA.prod_subset_le_topBlock`: any `m` terms are
  dominated by the `m` largest) and a **grouping crux**
  (`LOA.prodPow_le_topProd`: distinct-prime champion powers, grouped by the term
  they divide, are bounded by the largest terms).
* The four laws (`LOA.LOA_Erdos`, `LOA.principal`, `LOA.eloa_d1`, `LOA.eloa_lcm`)
  then follow, each using the basic result exactly as the problem asked.

See `ExplainLOA.md` for the declaration-by-declaration walkthrough and the
bibliography, and `ApplicationsLOA.md` for where these results appear in the
literature.
