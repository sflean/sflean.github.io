# ExplainPCB — step-by-step formal verification of the prime-counting bounds

This document walks through **how the two prime-counting bounds are verified in
Lean**, declaration by declaration. Everything lives in the `PCB` namespace and
is machine-checked in the Lean 4 project (Mathlib). The development builds with
no `sorry`, and uses only the standard axioms (`propext`, `Classical.choice`,
`Quot.sound`, and — for one finite `native_decide` check in `pi_le_b_wayII` —
`Lean.ofReduceBool`/`Lean.trustCompiler`).

The object of study is the **prime counting function**

```
π(k) = #{ p : p prime and p ≤ k }        (PCB.piCount)
```

and the two elementary upper bounds

```
a(k) = ⌈k/2⌉          (PCB.boundA,  realised as (k+1)/2)
b(k) = 1 + ⌈k/3⌉      (PCB.boundB,  realised as 1 + (k+2)/3).
```

We prove `π(k) ≤ a(k)` and `π(k) ≤ b(k)` for all `k`, **each in two independent
ways**, exactly as requested.

Files:

* `RequestProject/PCB/Defs.lean` — all definitions and the "prime-free" and
  "distinctness" facts about `UNO, DOS, TRES`.
* `RequestProject/PCB/WayI.lean` — the sieve / counting-function proof.
* `RequestProject/PCB/WayII.lean` — the induction / parity proof.
* `RequestProject/PCB/Main.lean` — a top-level index and the final theorems
  `PCB.pi_le_a`, `PCB.pi_le_b`.

These files are deliberately kept **separate** from the earlier
`A,B,C,D,E`/`AA,…,EE` development, so that the PCB material can be reused on its
own later.

---

## 0. Definitions (`Defs.lean`)

```
piCount k = #((Finset.Icc 1 k).filter Nat.Prime)
boundA  k = (k + 1) / 2                 -- ⌈k/2⌉
boundB  k = 1 + (k + 2) / 3             -- 1 + ⌈k/3⌉

UNO  = {1}
DOS  = {m | ∃ n, 1 < n ∧ m = 2*n}       -- the even numbers > 2
TRES = {m | ∃ n, 0 < n ∧ m = 3*(2*n+1)} -- the odd multiples of 3 that are > 3
```

The sets `UNO, DOS, TRES` are given exactly as in the problem statement (as
subsets of `ℕ`). For counting we also introduce **decidable characterisations**
and prove they match the set definitions:

```
dosP  m ↔ (2 < m ∧ 2 ∣ m)          -- PCB.mem_DOS
tresP m ↔ (3 < m ∧ m % 6 = 3)      -- PCB.mem_TRES
```

`mem_DOS`: `m = 2n` with `n > 1` is the same as "`m` even and `m > 2`". `mem_TRES`:
`m = 3(2n+1) = 6n+3` with `n > 0` is the same as "`m ≡ 3 (mod 6)` and `m > 3`".
Both are proved by unfolding and `omega` (the backward direction uses the witness
`n = m/2`, resp. `n = m/6`).

The counting functions on the window `[1,k]` are

```
cntUD   k = #(filter (m = 1 ∨ dosP m) (Icc 1 k))           -- counts UNO ∪ DOS
cntUDT  k = #(filter (m = 1 ∨ dosP m ∨ tresP m) (Icc 1 k)) -- counts UNO ∪ DOS ∪ TRES
cntTRES k = #(filter tresP (Icc 1 k))                      -- counts TRES
compUD  k = #(filter ¬(m = 1 ∨ dosP m) (Icc 1 k))          -- the complement of UNO ∪ DOS
compUDT k = #(filter ¬(m = 1 ∨ dosP m ∨ tresP m) (Icc 1 k))-- the complement of UNO ∪ DOS ∪ TRES
```

### 0.1 The three sets are prime-free and distinct

These are the structural facts Way I rests on.

* `no_prime_UNO`: a prime is never `1` (`Nat.Prime.ne_one`).
* `no_prime_DOS`: a prime `p ∈ DOS` would be even and `> 2`; but a prime divisible
  by `2` equals `2`, contradiction.
* `no_prime_TRES`: a prime `p ∈ TRES` satisfies `p % 6 = 3`, hence `3 ∣ p`; a prime
  divisible by `3` equals `3`, contradicting `p > 3`.
* `no_prime_union`: combining the three, no prime lies in `UNO ∪ DOS ∪ TRES`.
* `UNO_DOS_disjoint`, `UNO_TRES_disjoint`, `DOS_TRES_disjoint`: pairwise
  disjointness — `1` is neither in `DOS` nor `TRES`, and `DOS` is even while
  `TRES` is odd. (Proved via `Set.disjoint_left` + `omega`.)

---

## 1. Way I — the sieve / counting-function proof (`WayI.lean`)

**Idea.** Every prime lies in the complement of `UNO ∪ DOS` (§0.1), so
`π(k)` is at most the number of naturals in `[1,k]` outside `UNO ∪ DOS`. We
compute that complement count and find it is `a(k)`. Adjoining the third
prime-free set `TRES` gives the sharper bound `b(k)`.

### 1.1 Counting functions of the sieve sets

* **`cntUD_eq` : for `k ≥ 2`, `cntUD k = ⌊k/2⌋`.** The set `UNO ∪ DOS` on `[1,k]`
  is `{1} ∪ {4,6,8,…}`; the single element `1` exactly compensates for the
  missing even number `2`, so the total count is the number of even numbers
  `≤ k`, namely `⌊k/2⌋`. Formally: rewrite the card as a sum of indicators
  (`Finset.card_filter`) and induct from the base `k = 2` (`Nat.le_induction`),
  peeling the top term with `Finset.sum_Ioc_succ_top`; each step adds `1` exactly
  when `k+1` is even, which is precisely when `⌊k/2⌋` increases (`omega`).

* **`cntTRES_eq` : `cntTRES k = ⌊(k-3)/6⌋` (all `k`).** `TRES ∩ [1,k]` is
  `{9,15,21,…} ∩ [1,k]`, i.e. the numbers `6n+3 ≤ k` with `n ≥ 1`, of which there
  are `⌊(k-3)/6⌋` (natural-number subtraction and division handle the small
  cases automatically). Same induction scheme.

* **`cntUDT_eq` : `cntUDT k = cntUD k + cntTRES k`.** Because `UNO ∪ DOS` and
  `TRES` are disjoint (an element of `TRES` is odd, so it is neither `1` nor in
  `DOS`), the filter over the union splits as a disjoint union
  (`Finset.card_union_of_disjoint`).

### 1.2 Complement counting functions

* **`compUD_add_cntUD` : `compUD k + cntUD k = k`.** The predicate and its
  negation partition `Icc 1 k`, whose cardinality is `k`
  (`Finset.card_filter_add_card_filter_not`, `Nat.card_Icc`).
* **`compUDT_add_cntUDT` : `compUDT k + cntUDT k = k`.** Same partition argument.

* **`compUD_eq_boundA` : for `k ≥ 2`, `compUD k = a(k)`.** From
  `compUD k = k − cntUD k = k − ⌊k/2⌋ = ⌈k/2⌉ = a(k)` (`omega`). This is the
  step "the counting function of the complement set is `a(k)`".
* **`compUD_le_boundA` : `compUD k ≤ a(k)` for all `k`.** The equality gives it
  for `k ≥ 2`; the two remaining values `k = 0,1` are checked directly.
  (At `k = 1` the complement is empty, `0 < a(1) = 1`, the only place where the
  clean equality dips to a strict inequality.)
* **`compUDT_le_boundB` : `compUDT k ≤ b(k)` for all `k`.** For `k ≥ 2`,
  `compUDT k = k − cntUD k − cntTRES k = k − ⌊k/2⌋ − ⌊(k-3)/6⌋`, and the
  inequality `k − ⌊k/2⌋ − ⌊(k-3)/6⌋ ≤ 1 + ⌈k/3⌉` is a pure floor identity that
  `omega` discharges; the small values are checked directly. (The complement
  count equals `b(k)` for most `k` but dips below it at `k ∈ {0,1,2,4}` and the
  residues `k ≡ 4 (mod 6)`; only the `≤` direction is needed and it always
  holds.)

### 1.3 Primes lie in the complements

* **`pi_le_compUD` : `π(k) ≤ compUD k`.** The prime filter is a subset of the
  complement-of-`UNO ∪ DOS` filter: a prime is not `1` (`Nat.Prime.ne_one`) and
  is not an even number `> 2` (`Nat.Prime.eq_two_or_odd`). Monotonicity of
  cardinality (`Finset.card_mono`) finishes.
* **`pi_le_compUDT` : `π(k) ≤ compUDT k`.** Same, additionally excluding `TRES`:
  a prime with `p % 6 = 3` would be a multiple of `3` bigger than `3`, impossible
  (`Nat.Prime.dvd_iff_eq`).

### 1.4 The two bounds (Way I)

```
pi_le_a_wayI : π(k) ≤ a(k)   =  pi_le_compUD  ▸ compUD_le_boundA
pi_le_b_wayI : π(k) ≤ b(k)   =  pi_le_compUDT ▸ compUDT_le_boundB
```

Since the primes are a subset of each complement, and the complement counts are
`≤ a(k)` resp. `≤ b(k)`, the bounds follow by transitivity.

---

## 2. Way II — the induction / parity proof (`WayII.lean`)

**Idea.** Increasing `k` by `2` can add at most one prime (one of the two new
numbers is even hence composite); this gives `π(k) ≤ a(k)`. A sharper
`mod 3 + mod 2` bookkeeping gives `π(k) ≤ b(k)`.

### 2.1 The two-step inequality

* **`pi_add_two_le` : for `k ≥ 2`, `π(k+2) ≤ π(k) + 1`.** Split
  `Icc 1 (k+2) = Icc 1 k ∪ {k+1, k+2}` and filter by primality
  (`Finset.filter_union`). Of the two consecutive numbers `k+1, k+2` one is even,
  and since `k ≥ 2` that even number is `≥ 4`, hence not prime
  (`Nat.Prime.eq_two_or_odd` rules out an even prime `> 2`). So at most one of the
  two is prime, contributing at most `1`.

* **`pi_le_a_wayII` : `π(k) ≤ a(k)`.** Strong induction (`Nat.strong_induction_on`).
  The bases `k = 0,1,2,3` are computed directly. For `k ≥ 4`, apply
  `pi_add_two_le (k-2)` and the induction hypothesis, using
  `a(k) = a(k-2) + 1` (`omega`).

### 2.2 The `mod 3` refinement

* **`pi_three_mul_succ_eq` : for `k > 0`, `π(3(k+1)) = π(3k+2)`.** Since
  `3(k+1) = (3k+2)+1`, the only new candidate is `3k+3 = 3(k+1)`, which is a
  multiple of `3` bigger than `3`, hence composite (`Nat.not_prime_mul`). So the
  count is unchanged. This is exactly the requested fact "`π(3(k+1)) = π(3k+2)`".

* **`pi_three_step` : for `k > 0`, `π(3k+3) ≤ 1 + π(3k)`.** Combine the previous
  equality `π(3k+3) = π(3k+2)` with `pi_add_two_le (3k)` (valid since `3k ≥ 2`),
  which gives `π(3k+2) ≤ π(3k) + 1`.

* **`pi_mul_three_le` : `π(3j) ≤ 1 + j`.** Induction on `j`: bases `j = 0`
  (`π(0) = 0`) and `j = 1` (`π(3) = 2`); the step for `j ≥ 1` uses
  `pi_three_step j`. Note `1 + j = b(3j)`, so this is the bound on the multiples
  of `3`.

* **`pi_le_b_wayII` : `π(k) ≤ b(k)`.** Write `k = 3j + r` with `r < 3`
  (`Nat.div_add_mod`). For `r = 0`, apply `pi_mul_three_le` (`b(3j) = 1 + j`).
  For `r ∈ {1,2}`, `b(k) = j + 2`; monotonicity of `π` (`Finset.card_mono`,
  `Finset.Icc_subset_Icc_right`) gives `π(k) ≤ π(3j+2)`, and
  `π(3j+2) ≤ π(3j) + 1 ≤ (1+j) + 1 = j + 2`. The small block `k ≤ 2` is settled
  by `native_decide`.

---

## 3. Final results (`Main.lean`)

```
PCB.pi_le_a : ∀ k, π(k) ≤ a(k)     -- = pi_le_a_wayI
PCB.pi_le_b : ∀ k, π(k) ≤ b(k)     -- = pi_le_b_wayI
```

Both bounds are also available through the independent Way II proofs
`PCB.pi_le_a_wayII`, `PCB.pi_le_b_wayII`, giving two genuinely different
certificates for each inequality.

---

## Bibliography

### Mathlib lemmas and tactics used

| lemma / tactic | used for |
|---|---|
| `Nat.Prime.ne_one` | primes are not `1` (§0.1, §1.3) |
| `Nat.Prime.eq_two_or_odd` | an even prime is `2` (§1.3, §2.1) |
| `Nat.Prime.dvd_iff_eq` | a prime dividing `3` equals `3` (§0.1, §1.3) |
| `Nat.not_prime_mul` | `3(k+1)` is composite (§2.2) |
| `Nat.dvd_of_mod_eq_zero` | `m % 6 = 3 ⇒ 3 ∣ m` (§0.1, §1.3) |
| `Finset.card_filter` | card as sum of indicators (§1.1) |
| `Finset.sum_Ioc_succ_top`, `Finset.sum_Ico_succ_top` | peel the top term in inductions (§1.1, §2.2) |
| `Finset.Icc_succ_left_eq_Ioc` | rewrite `Icc` as `Ioc` for the peel (§1.1) |
| `Finset.card_union_of_disjoint` | additivity of counts over a disjoint union (§1.1) |
| `Finset.disjoint_left` | disjointness of the sieve sets (§0.1, §1.1) |
| `Finset.card_filter_add_card_filter_not` | a predicate and its negation partition (§1.2) |
| `Nat.card_Icc` | `#(Icc 1 k) = k` (§1.2) |
| `Finset.sum_add_distrib`, `Finset.sum_const`, `Finset.card_eq_sum_ones` | count bookkeeping (§1.2) |
| `eq_tsub_of_add_eq` | turn `x + y = k` into `x = k − y` (§1.2) |
| `Finset.card_mono`, `Finset.card_le_card`, `Finset.filter_subset_filter` | subset ⇒ smaller count (§1.3, §2.1–2.2) |
| `Finset.Icc_subset_Icc_right` | monotonicity of `π` (§2.2) |
| `Finset.filter_union`, `Finset.filter_insert`, `Finset.filter_singleton` | split `Icc 1 (k+2)` (§2.1) |
| `Nat.strong_induction_on` | the `π ≤ a` induction (§2.1) |
| `Nat.div_add_mod`, `Nat.mod_lt` | write `k = 3j + r` (§2.2) |
| `omega` | all floor/`div`/`mod` arithmetic |
| `decide` / `native_decide` | finite base cases (§1.1, §2.2) |

### Classical mathematical background (well-known sources)

The facts above are textbook material rather than niche references.

* The **prime counting function `π`** and elementary sieving bounds of the form
  `π(k) ≤ ⌈k/2⌉` (all primes but `2` are odd) and
  `π(k) ≤ 1 + ⌈k/3⌉` (all primes but `2, 3` are coprime to `6`) are standard
  exercises; see e.g. G. H. Hardy and E. M. Wright, *An Introduction to the
  Theory of Numbers* (Oxford), and T. M. Apostol, *Introduction to Analytic
  Number Theory* (Springer), the chapters on the distribution of primes.
* The observation that, past `3`, every prime is `≡ 1` or `5 (mod 6)` — the
  arithmetic content of the `b(k)` bound — is the elementary "`6k ± 1`" fact
  about primes, again standard textbook material.
