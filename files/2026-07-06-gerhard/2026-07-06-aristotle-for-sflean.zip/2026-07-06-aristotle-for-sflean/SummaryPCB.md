# SummaryPCB — bounds on the prime counting function

This project formally verifies, in Lean 4 (with Mathlib), two elementary upper
bounds on the **prime counting function**

```
π(k) = #{ p : p prime and p ≤ k }
```

namely

```
π(k) ≤ a(k) = ⌈k/2⌉          and          π(k) ≤ b(k) = 1 + ⌈k/3⌉,     for all k ∈ ℕ,
```

and it does so **in two independent ways**, as requested. The whole development
builds with no `sorry` and relies only on the standard axioms.

## The two bounds in one line

* `a(k) = ⌈k/2⌉`: apart from `2`, every prime is **odd**, so at most half of
  `1,…,k` can be prime.
* `b(k) = 1 + ⌈k/3⌉`: apart from `2` and `3`, every prime is **coprime to `6`**
  (i.e. `≡ 1` or `5 (mod 6)`), which is a stronger sieve and gives the sharper
  `1 + ⌈k/3⌉`.

Both are proved for *every* `k`.

## Way I — a sieve of three prime-free sets

Introduce the three sets from the problem statement

```
UNO  = {1},   DOS = {2n : n > 1},   TRES = {3(2n+1) : n > 0},
```

i.e. `{1}`, the even numbers `> 2`, and the odd multiples of `3` that are `> 3`.

* **They contain no primes**, and **they are pairwise disjoint** (formal lemmas
  `no_prime_union`, `UNO_DOS_disjoint`, `UNO_TRES_disjoint`, `DOS_TRES_disjoint`).
* **Counting functions.** On the window `[1,k]`:
  * `#(UNO ∪ DOS)  = ⌊k/2⌋` (for `k ≥ 2`) — the extra element `1` exactly makes
    up for the missing even number `2`;
  * `#TRES = ⌊(k-3)/6⌋`, and since `TRES` is disjoint from `UNO ∪ DOS`,
    `#(UNO ∪ DOS ∪ TRES) = ⌊k/2⌋ + ⌊(k-3)/6⌋`.
* **Complements.** Since the sets partition `[1,k]` with their complements,
  ```
  #(complement of UNO ∪ DOS)        = k − ⌊k/2⌋       = ⌈k/2⌉  = a(k),
  #(complement of UNO ∪ DOS ∪ TRES) ≤ 1 + ⌈k/3⌉       = b(k).
  ```
* **Conclusion.** The primes are a **subset** of each complement (they avoid all
  three prime-free sets), so
  ```
  π(k) ≤ #(complement) = a(k),      and      π(k) ≤ #(complement) ≤ b(k).
  ```

(One honest caveat, handled in the formalisation: the complement count equals
`a(k)` for `k ≥ 2`, dropping to `0 < a(1)` only at `k = 1`; and it is `≤ b(k)`
with a few small strict dips. The inequalities needed for the bounds always
hold.)

## Way II — induction and parity

* **Step of 2.** `π(k+2) ≤ π(k) + 1` for `k ≥ 2`: of the two new numbers
  `k+1, k+2` one is even and `≥ 4`, hence composite, so at most one new prime
  appears. Feeding this into an induction (with `a(k) = a(k-2)+1`) gives
  `π(k) ≤ a(k)`.

* **Step of 3.** For `k > 0`, `3(k+1)` is a multiple of `3` bigger than `3`,
  hence composite; therefore
  ```
  π(3(k+1)) = π(3k+2).
  ```
  Combining this with the step-of-2 fact `π(3k+2) ≤ π(3k) + 1` yields
  ```
  π(3k+3) ≤ 1 + π(3k)      (k > 0).
  ```
  Iterating along the multiples of `3` gives `π(3j) ≤ 1 + j = b(3j)`, and a short
  monotonicity argument extends this to all `k`, giving `π(k) ≤ b(k)`.

## What is formalised

| statement | name |
|---|---|
| `π(k) ≤ a(k)` (final) | `PCB.pi_le_a` |
| `π(k) ≤ b(k)` (final) | `PCB.pi_le_b` |
| Way I bounds | `PCB.pi_le_a_wayI`, `PCB.pi_le_b_wayI` |
| Way II bounds | `PCB.pi_le_a_wayII`, `PCB.pi_le_b_wayII` |
| sets are prime-free / distinct | `PCB.no_prime_union`, `PCB.*_disjoint` |
| counting functions | `PCB.cntUD_eq`, `PCB.cntTRES_eq`, `PCB.cntUDT_eq` |
| complement counts | `PCB.compUD_eq_boundA`, `PCB.compUD_le_boundA`, `PCB.compUDT_le_boundB` |
| `π(k+2) ≤ π(k)+1` | `PCB.pi_add_two_le` |
| `π(3(k+1)) = π(3k+2)` | `PCB.pi_three_mul_succ_eq` |
| `π(3k+3) ≤ 1 + π(3k)` | `PCB.pi_three_step` |

See `ExplainPCB.md` for the step-by-step verification and the bibliography of
Mathlib lemmas used, and `ApplicationsPCB.md` for where these bounds and
techniques appear in the literature.
