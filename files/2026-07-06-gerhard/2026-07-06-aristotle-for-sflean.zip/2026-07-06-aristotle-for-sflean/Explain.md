# Explain — step-by-step formal verification / refutation

This document walks through **how each comparison is verified (or refuted) in
Lean**, declaration by declaration. All statements live in the `Bounds`
namespace and are machine-checked in the Lean 4 project (Mathlib). The whole
development builds with no `sorry` and uses only the standard axioms
(`propext`, `Classical.choice`, `Quot.sound`, and — for the finite
`native_decide` checks — `Lean.ofReduceBool`/`Lean.trustCompiler`).

Notation: `hc k = ⌈k/2⌉ = (k+1)/2`, so `k - hc k = ⌊k/2⌋`.

Files:

* `RequestProject/Defs.lean` — definitions of `A, B, C, D, E`, the chain and the
  products `AA, BB, CC, DD, EE`.
* `RequestProject/SingleIndex.lean` — the single-index comparisons.
* `RequestProject/Products.lean` — the iterated (`r`-fold) comparisons.
* `RequestProject/Main.lean` — a top-level index of every result.

---

## 0. Definitions (`Defs.lean`)

```
hc k    = (k + 1) / 2
A k     = ∏ p ∈ (Ioc (hc k) k).filter Nat.Prime, p
Bpred k p = Nat.Prime p ∧ ∃ e ∈ Icc 1 k, hc k < p^e ∧ p^e ≤ k
B k     = ∏ p ∈ (range (k+1)).filter (Bpred k), p
C k     = Nat.choose k (hc k)
D k     = 4 ^ (k - hc k)
E k     = Nat.choose (2 * hc k) (hc k)
chain k i = hc^[i] k
AA/BB/CC/DD/EE k r = ∏ i ∈ range r, (A/B/C/D/E) (chain k i)
```

In `B`, the exponent search `∃ e ∈ Icc 1 k` is a finite (decidable) rewrite of
`∃ e ≥ 1`: any `e` with `p^e ≤ k` satisfies `e ≤ k`, so the bounded and
unbounded forms describe the same set of primes.

Basic facts (`hc_le_self`, `le_two_mul_hc`, `sub_hc_le_hc`) record
`hc k ≤ k`, `k ≤ 2·hc k`, and `k − hc k ≤ hc k`; positivity lemmas
(`C_pos, D_pos, E_pos, A_pos, B_pos`) note that all five quantities are positive
(products of primes, or binomial coefficients with a valid index).

---

## 1. Single-index comparisons (`SingleIndex.lean`)

### 1.1 `A ≤ B`  (`A_le_B`)

The index set of `A` is a subset of the index set of `B`: a prime with
`hc k < p ≤ k` is the `e = 1` witness for `Bpred`. Since every factor is a prime
`≥ 1`, multiplying over the larger set only increases the product. Verified with
`Finset.prod_le_prod_of_subset_of_one_le'`.

### 1.2 `A ∣ C`, hence `A ≤ C`  (`prime_dvd_C_of_mem_Aset`, `A_dvd_C`, `A_le_C`)

For a prime `p` with `hc k < p ≤ k`: it satisfies `hc k < p`, `k − hc k < p`
(because `k − hc k ≤ hc k < p`), and `p ≤ k`, which is exactly the hypothesis of
`Nat.Prime.dvd_choose`, giving `p ∣ C(k, hc k)`. Distinct primes are pairwise
coprime, so `Finset.prod_primes_dvd` yields `A k ∣ C k`, and
`Nat.le_of_dvd` (with `C k > 0`) gives `A k ≤ C k`.

### 1.3 `B ∣ C`, hence `B ≤ C`  (`prime_dvd_C_of_mem_Bset`, `B_dvd_C`, `B_le_C`)

This is the key number-theoretic step. Fix a prime `p` and an `e ≥ 1` with
`hc k < p^e ≤ k`. By **Legendre's formula** (Mathlib
`Nat.factorization_choose`), the `p`-adic valuation of `C(k, hc k)` equals the
number of `i ∈ [1, k]` with `p^i ≤ (hc k mod p^i) + ((k − hc k) mod p^i)`
(the count of base-`p` carries when adding `hc k` and `k − hc k`). Take `i = e`:
since `hc k < p^e` we have `hc k mod p^e = hc k`, and since
`k − hc k ≤ hc k < p^e` we have `(k − hc k) mod p^e = k − hc k`; their sum is
`k ≥ p^e`. So `e` is counted, the valuation is `≥ 1`, and therefore `p ∣ C k`
(`Nat.Prime.dvd_iff_one_le_factorization`). As before, `Finset.prod_primes_dvd`
lifts this to `B k ∣ C k`, and `Nat.le_of_dvd` gives `B k ≤ C k`.

### 1.4 `C ≤ D`  (`C_le_D`)

Let `n = k − hc k = ⌊k/2⌋`. By the symmetry `Nat.choose_symm`,
`C(k, hc k) = C(k, n)`. Since `k ≤ 2n+1`, `Nat.choose_le_choose` gives
`C(k, n) ≤ C(2n+1, n)`, and the classical bound `Nat.choose_middle_le_pow`
gives `C(2n+1, n) ≤ 4^n = D k`.

### 1.5 `C ≤ E`, with equality iff `k` even  (`C_le_E`, `C_eq_E_of_even`, `C_lt_E_of_odd`, `C_eq_E_iff`)

`C(k) = C(k, hc k)` and `E(k) = C(2·hc k, hc k)`. As `k ≤ 2·hc k`,
`Nat.choose_le_choose` gives `C ≤ E`.
- If `k` is even then `2·hc k = k`, so `C = E` (rewrite).
- If `k` is odd then `2·hc k = k+1`, and Pascal's rule
  `(k+1).choose (j+1) = k.choose j + k.choose (j+1)` with `k.choose j > 0`
  makes the inequality **strict**.
Combining (`Nat.even_or_odd`) yields `C k = E k ↔ Even k`.

### 1.6 `E ≤ D` except `k ∈ {1,3,5,7}`  (`E_le_D`) and the refutations (`D_lt_E_exceptions`)

Two auxiliary bounds:
- `cb_le_four_pow`: `C(2m,m) ≤ 4^m` (from `choose_le_choose` + `choose_middle_le_pow`).
- `centralBinom_le_four_pow_pred`: `C(2n,n) ≤ 4^{n-1}` for `n ≥ 5`, proved by
  induction using `Nat.succ_mul_centralBinom_succ`
  (`(n+1)·C(2n+2,n+1) = 2(2n+1)·C(2n,n)`); the growth factor `2(2n+1)/(n+1)` is
  `< 4`, and the base case `n = 5` (`252 ≤ 256`) is checked by `native_decide`.

Then:
- **even `k`:** `k − hc k = hc k`, and `E k = C(2·hc k, hc k) ≤ 4^{hc k} = D k`.
- **odd `k ∉ {1,3,5,7}` (so `k ≥ 9`):** here `hc k ≥ 5` and `k − hc k = hc k − 1`,
  so `E k = C(2·hc k, hc k) ≤ 4^{hc k − 1} = D k`.

The four omitted values are genuine **refutations**: `D_lt_E_exceptions` proves
`D 1 < E 1`, `D 3 < E 3`, `D 5 < E 5`, `D 7 < E 7` by direct computation
(`1<2`, `4<6`, `16<20`, `64<70`).

### 1.7 Transitive corollaries

`A_le_D = A_le_C ∘ C_le_D`, `A_le_E = A_le_C ∘ C_le_E`,
`B_le_D = B_le_C ∘ C_le_D`, `B_le_E = B_le_C ∘ C_le_E`.

### 1.8 Equality sets (computational remarks)

The **inequalities above are proved for all `k`.** The exact sets where equality
holds were determined by computation (checked for `k < 400`) and are recorded
here for completeness (they are not part of the formal claims, except
`C = E ⇔ k even` and the `D`/`E` exceptions, which *are* proved):

| relation | equality at `k =` |
|---|---|
| `A = B` | `0,1,2,3,7` |
| `A = C` | `0,1,2,3,7` |
| `A = D` | `0,1` |
| `A = E` | `0,2` |
| `B = C` | `0,1,2,3,4,5,7,8,11,19` |
| `B = D` | `0,1` |
| `B = E` | `0,2,4,8` |
| `C = D` | `0,1` |
| `C = E` | all even `k` (**proved**) |
| `D`,`E`  | `D < E` exactly at `k = 1,3,5,7` (**proved**) |

No pair of `A,B,C,D,E` is ever incomparable.

---

## 2. Iterated (`r`-fold) comparisons (`Products.lean`)

### 2.1 Chain algebra

`chain k 0 = k` and `chain k (i+1) = chain (hc k) i = hc (chain k i)`
(`Function.iterate_succ_apply`/`'`). The chain is non-increasing
(`chain_step_le`, `chain_antitone`) and monotone in the start value
(`chain_mono`). Peeling the first factor with `Finset.prod_range_succ'` gives the
recurrences `AA_succ, BB_succ, CC_succ, DD_succ, EE_succ`, e.g.
`DD k (r+1) = D k · DD (hc k) r`.

### 2.2 Factor-wise product inequalities

Because each single-index inequality holds for **all** indices, the helper
`prod_chain_le` (from `Finset.prod_le_prod'`) immediately gives, for all `k, r`:

`AA_le_BB, AA_le_CC, AA_le_DD, AA_le_EE, BB_le_CC, BB_le_DD, BB_le_EE,
CC_le_DD, CC_le_EE`.

### 2.3 `CC = EE` iff all chain elements are even  (`CC_eq_EE_iff`)

By induction on `r`, using `Finset.prod_range_succ` and the cancellation helper
`mul_eq_mul_split` (if `a ≤ b`, `c ≤ d`, `c,b > 0` and `a·c = b·d` then `a = b`
and `c = d`, valid since the factors are positive). Each factor equality
`C(j_i) = E(j_i)` is exactly `Even (j_i)` by `C_eq_E_iff`.

### 2.4 `DD ≥ EE` with the seven exceptions  (`EE_le_DD`, `DD_lt_EE_exceptions`)

The exceptional set is
`Exc = {(3,1),(5,1),(5,2),(7,1),(9,2),(9,3),(17,4)}`.

**Refutation of the seven pairs.** `DD_lt_EE_exceptions` proves
`DD k r < EE k r` for each pair in `Exc` by `native_decide`.

**Verification everywhere else.** `EE_le_DD` proves: for all `k, r` with
`1 < chain k r` and `(k,r) ∉ Exc`, `EE k r ≤ DD k r`. The proof is strong
induction on `k`:

* **`k ≤ 34`.** The validity `1 < chain k r` forces `r ≤ 5` (`r_bound`: the chain
  is non-increasing and `chain k 6 ≤ chain 34 6 = 1`). The remaining finite
  statement — for all `k < 35`, `r < 6`, valid and non-exceptional pairs satisfy
  `EE ≤ DD` — is checked once and for all by `native_decide` (`base_check`).
  This is exactly the step that certifies the seven exceptions are the *only*
  ones with small `k`.
* **`k ≥ 35`.** Split on `r`. For `r = 0` both products are `1`. For `r+1`, use
  `DD k (r+1) = D k · DD (hc k) r` and `EE k (r+1) = E k · EE (hc k) r`. Here
  `hc k ≥ 18`, so `(hc k, r) ∉ Exc` (all first coordinates of `Exc` are `≤ 17`);
  the induction hypothesis gives `EE (hc k) r ≤ DD (hc k) r`, and
  `E k ≤ D k` (`E_le_D`, valid since `k ≥ 35`). Multiplying (`Nat.mul_le_mul`)
  closes the goal.

Why the exceptions cannot recur for large `k`: any exceptional sub-chain must
start at one of `3,5,7,9,17`, and once `k ≥ 35` the second chain element
`hc k ≥ 18` is already past all of them, while the head factor `D(k) ≥ E(k)`
never hurts.

---

## Bibliography

### Mathlib lemmas used

| lemma | used for |
|---|---|
| `Nat.Prime.dvd_choose` | `A ∣ C` (§1.2) |
| `Nat.factorization_choose` (Legendre's formula / carries) | `B ∣ C` (§1.3) |
| `Nat.Prime.dvd_iff_one_le_factorization` | `B ∣ C` (§1.3) |
| `Nat.log_le_self` | bound `log p k < k+1` in §1.3 |
| `Finset.prod_primes_dvd` | product of distinct primes divides `C` (§1.2–1.3) |
| `Nat.le_of_dvd` | turn divisibility into `≤` (§1.2–1.3) |
| `Nat.choose_symm` | `C(k, hc k) = C(k, ⌊k/2⌋)` (§1.4) |
| `Nat.choose_le_choose` | monotonicity of `C(·, r)` (§1.4–1.5) |
| `Nat.choose_middle_le_pow` (`C(2n+1,n) ≤ 4^n`) | `C ≤ D`, central bound (§1.4, §1.6) |
| `Nat.choose_succ_succ` (Pascal) | strictness for odd `k` (§1.5) |
| `Nat.centralBinom_eq_two_mul_choose` | rewriting `C(2n,n)` (§1.6) |
| `Nat.succ_mul_centralBinom_succ` (recurrence) | induction `C(2n,n) ≤ 4^{n-1}` (§1.6) |
| `Finset.prod_le_prod_of_subset_of_one_le'` | `A ≤ B` (§1.1) |
| `Finset.prod_le_prod'` | factor-wise product inequalities (§2.2) |
| `Finset.prod_range_succ`, `Finset.prod_range_succ'` | product recurrences (§2.1, §2.3) |
| `Finset.prod_pos` | positivity of products (§0, §2.3) |
| `Function.iterate_succ_apply`, `Function.iterate_succ_apply'` | chain recurrences (§2.1) |
| `Nat.strong_induction_on` | the `DD ≥ EE` induction (§2.4) |
| `Nat.eq_of_mul_eq_mul_left/right` | cancellation helper (§2.3) |
| `native_decide` / `decide` | finite base check and the seven refutations (§1.6, §2.4) |

### Classical mathematical background (well-known sources)

These are the standard facts the Mathlib lemmas encode; they are textbook
material rather than niche references.

* **Legendre's formula / Kummer's theorem** for the `p`-adic valuation of
  factorials and binomial coefficients (the base-`p` "carry" description used in
  §1.3). Standard number theory; see e.g. G. H. Hardy and E. M. Wright,
  *An Introduction to the Theory of Numbers*.
* **The central binomial bound `C(2n,n) ≤ 4^n`** and the divisibility of central
  binomial coefficients by primes in `(n, 2n]`, as used in the Erdős proof of
  **Bertrand's postulate**; see M. Aigner and G. M. Ziegler,
  *Proofs from THE BOOK*, chapter "Bertrand's postulate".
