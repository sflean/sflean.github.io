import RequestProject.LOA.Erdos
import RequestProject.LOA.ELOA

/-!
# Laws Of Ademption — top-level index

This development formalises the **basic result** on arithmetic progressions
`n + d, n + 2·d, …, n + k·d` (`n, k, d : ℕ`, `d ≥ 1`, `gcd(n, d) = 1`) and its
consequences (the Laws Of Ademption).

## Definitions (`RequestProject/LOA/Defs.lean`)

* `LOA.apProd n d k = ∏_{j=1}^{k} (n + j·d)` — product of the `k` terms.
* `LOA.topProd n d k r = ∏_{j=k-r+1}^{k} (n + j·d)` — product of the `r` largest terms.

## The basic result (`RequestProject/LOA/Basic.lean`)

* `LOA.basic` : for a prime `p` with `p ∤ d` and a `p`-adic argmax term `n + i·d`,
  `v_p(∏_{j=1}^k (n+j·d)) ≤ v_p((k-1)!) + v_p(n+i·d)`.
* `LOA.basic_exists` : the same with the argmax `i` produced existentially.

## Consequences

* `LOA.LOA_Erdos` (`Erdos.lean`) : if `p` is prime and `p^e ∣ C(n+k,k)` (with
  `0 < n+k`) then `p^e ≤ n+k`.
* `LOA.principal` (`ELOA.lean`) : the ELOA Principal Lemma (product form, general
  `d`): if `∏_{p∈P} p^(e p) ∣ ∏_{j=1}^k (n+j·d)` with `#P < k`, then
  `∏_{p∈P} p^(e p) ≤ (k-1)! · topProd n d k #P`.
* `LOA.eloa_d1` (`ELOA.lean`) : the `d = 1` product form, with bound
  `k! · ∏_{i=1}^{#P} (n + k + 1 - i)`.
* `LOA.eloa_lcm` (`ELOA.lean`) : the LCM form (general `d`):
  `lcm_{p∈P} p^(e p) ≤ (lcm_{p∈P} p^{v_p((k-1)!)}) · (lcm_{p∈P} (n + (J p)·d))`
  for `p`-adic argmax indices `J p`.

All final theorems depend only on the standard axioms
`propext`, `Classical.choice`, `Quot.sound`.
-/
