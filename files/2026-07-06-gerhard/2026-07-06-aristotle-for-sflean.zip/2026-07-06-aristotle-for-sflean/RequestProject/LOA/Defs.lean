import Mathlib

/-!
# Definitions for the Laws Of Ademption (LOA)

We study arithmetic progressions with initial term `n + d`, common difference `d`
and `k` terms:
`n + d, n + 2·d, …, n + k·d`, where `n, k, d : ℕ`, `d ≥ 1` and `gcd(n, d) = 1`.

The `j`-th term is `n + j·d` for `1 ≤ j ≤ k`.

## Main definitions

* `LOA.apProd n d k = ∏_{j=1}^{k} (n + j·d)` — the product of the `k` terms.
* `LOA.topProd n d k r = ∏_{j = k-r+1}^{k} (n + j·d)` — the product of the `r`
  largest terms, i.e. `∏_{i=1}^{r} (n + (k+1-i)·d)`.

The quantities `n, k, d` are natural numbers.  Every term `n + j·d` with
`1 ≤ j` and `1 ≤ d` is positive.
-/

open scoped BigOperators
open Finset

namespace LOA

/-- The product of the `k` terms of the arithmetic progression
`n + d, n + 2d, …, n + k d`, i.e. `∏_{j=1}^{k} (n + j·d)`. -/
def apProd (n d k : ℕ) : ℕ := ∏ j ∈ Finset.Icc 1 k, (n + j * d)

/-- The product of the `r` largest terms of the arithmetic progression,
`∏_{j=k-r+1}^{k} (n + j·d) = ∏_{i=1}^{r} (n + (k+1-i)·d)`. -/
def topProd (n d k r : ℕ) : ℕ := ∏ j ∈ Finset.Icc (k - r + 1) k, (n + j * d)

/-- Every term of the progression is positive (when `1 ≤ d` and `1 ≤ j`). -/
lemma term_pos {d j : ℕ} (hd : 1 ≤ d) (hj : 1 ≤ j) (n : ℕ) : 0 < n + j * d := by
  have : 1 ≤ j * d := Nat.one_le_iff_ne_zero.mpr (by positivity)
  omega

/-- The product of the terms is positive (when `1 ≤ d`). -/
lemma apProd_pos {d : ℕ} (hd : 1 ≤ d) (n k : ℕ) : 0 < apProd n d k := by
  unfold apProd
  apply Finset.prod_pos
  intro j hj
  rw [Finset.mem_Icc] at hj
  exact term_pos hd hj.1 n

lemma apProd_ne_zero {d : ℕ} (hd : 1 ≤ d) (n k : ℕ) : apProd n d k ≠ 0 :=
  (apProd_pos hd n k).ne'

end LOA
