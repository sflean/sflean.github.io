import RequestProject.LOA.Basic

/-!
# LOA Erdős

The first consequence of the basic result:

**LOA Erdős.** If `p` is a prime and `p^e ∣ C(n+k, k)` (with `0 < n + k`), then
`p^e ≤ n + k`.

The proof specialises the basic result to the progression with `d = 1` (so the
terms are the consecutive integers `n+1, …, n+k`), using the identity
`C(n+k,k)·k! = ∏_{j=1}^k (n+j) = apProd n 1 k`.  The valuation of `C(n+k,k)` at `p`
is then at most the maximal valuation `v_p(n+i)` of a single term, whose prime
power `p^{v_p(n+i)}` divides `n+i ≤ n+k`.
-/

open scoped BigOperators
open Finset

namespace LOA

/-
For `d = 1` the product of the terms is `C(n+k,k)·k!`.
-/
lemma apProd_one_eq_choose_mul_factorial (n k : ℕ) :
    apProd n 1 k = (n + k).choose k * Nat.factorial k := by
  suffices h_suff : ∏ j ∈ Finset.Icc 1 k, (n + j) = (n + k).choose k * k.factorial by
    simpa [ apProd ] using h_suff;
  rw [ mul_comm, ← Nat.descFactorial_eq_factorial_mul_choose ];
  erw [ Finset.prod_Ico_eq_prod_range, Nat.descFactorial_eq_prod_range ];
  rw [ ← Finset.prod_range_reflect ];
  refine' Finset.prod_congr rfl fun x hx => by cases k <;> norm_num at * ; omega;

/-
**LOA Erdős.** If `p` is prime and `p^e ∣ C(n+k, k)` (and `0 < n+k`), then
`p^e ≤ n + k`.
-/
theorem LOA_Erdos {p e n k : ℕ} (hp : p.Prime) (hnk : 0 < n + k)
    (hdvd : p ^ e ∣ (n + k).choose k) : p ^ e ≤ n + k := by
  by_cases hk : 1 ≤ k;
  · -- By `basic_exists`, there exists `i ∈ Finset.Icc 1 k` such that `(apProd n 1 k).factorization p ≤ ((k-1)!).factorization p + (n + i).factorization p`.
    obtain ⟨i, hi⟩ : ∃ i ∈ Finset.Icc 1 k, (apProd n 1 k).factorization p ≤ ((Nat.factorial (k - 1)).factorization p) + (n + i).factorization p := by
      obtain ⟨ i, hi, hmax ⟩ := basic_exists hp ( show ¬ p ∣ 1 from by aesop ) hk n;
      aesop;
    -- Since `apProd n 1 k = C * k!`, we have `(apProd n 1 k).factorization p = C.factorization p + (k!).factorization p`.
    have h_factorization : (apProd n 1 k).factorization p = (Nat.choose (n + k) k).factorization p + (Nat.factorial k).factorization p := by
      rw [ apProd_one_eq_choose_mul_factorial, Nat.factorization_mul ] <;> norm_num [ Nat.factorial_ne_zero ];
      exact Nat.ne_of_gt <| Nat.choose_pos <| by linarith;
    -- Since `k! = k * (k-1)!`, we have `(k!).factorization p = (k).factorization p + ((k-1)!).factorization p`.
    have h_factorial : (Nat.factorial k).factorization p = (Nat.factorization k) p + (Nat.factorial (k - 1)).factorization p := by
      rw [ ← Nat.choose_mul_factorial_mul_factorial ( show 1 ≤ k from hk ), Nat.factorization_mul, Nat.factorization_mul ] <;> first | positivity | aesop;
    -- Since `p^e ∣ C` and `C ≠ 0`, we have `e ≤ C.factorization p`.
    have h_exp : e ≤ (Nat.choose (n + k) k).factorization p := by
      have := Nat.factorization_le_iff_dvd ( by aesop ) ( Nat.ne_of_gt <| Nat.choose_pos <| by linarith ) |>.2 hdvd ; aesop;
    exact Nat.le_trans ( Nat.pow_le_pow_right hp.pos ( show e ≤ ( n + i ).factorization p from by linarith ) ) ( Nat.le_of_dvd ( by linarith [ Finset.mem_Icc.mp hi.1 ] ) ( Nat.ordProj_dvd _ _ ) ) |> le_trans <| by linarith [ Finset.mem_Icc.mp hi.1 ] ;
  · aesop

end LOA