import RequestProject.LOA.Basic

/-!
# The extended Laws Of Ademption (ELOA)

Three further consequences of the basic result (`LOA.basic` / `LOA.basic_exists`):

* `LOA.eloa_lcm` — the LCM form (general `d`).
* `LOA.principal` — the ELOA Principal Lemma (product form, general `d`).
* `LOA.eloa_d1` — the `d = 1` product form.

All concern the progression `n + d, …, n + k·d` with `d ≥ 1`, `gcd(n,d) = 1`, and a
finset `P` of distinct primes with `#P < k`.  Exponents `e p` are allowed to be `0`
(so `P` may include primes not dividing the product).
-/

open scoped BigOperators
open Finset

namespace LOA

/-
A finset product of prime powers of **distinct** primes, each dividing `m`,
divides `m`.
-/
lemma prod_primePow_dvd {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime) {E : ℕ → ℕ} {m : ℕ}
    (hm : m ≠ 0) (hdvd : ∀ p ∈ P, p ^ (E p) ∣ m) :
    (∏ p ∈ P, p ^ (E p)) ∣ m := by
  induction' P using Finset.induction with p P hP ih;
  · norm_num;
  · simp_all +decide [ Finset.prod_insert, Nat.Prime.coprime_iff_not_dvd ];
    refine' Nat.Coprime.mul_dvd_of_dvd_of_dvd _ hdvd.1 ih;
    exact Nat.Coprime.prod_right fun q hq => Nat.Coprime.pow _ _ <| hP.1.coprime_iff_not_dvd.mpr fun h => ‹p ∉ P› <| by have := Nat.prime_dvd_prime_iff_eq hP.1 ( hP.2 q hq ) ; aesop;

/-
**Per-prime consequence of the basic result.** If `p` is prime, `gcd(n,d)=1`,
`1 ≤ d`, `1 ≤ k` and `p^e ∣ ∏_{j=1}^k (n + j·d)`, then there is a term index `i`
(a `p`-adic argmax) with `e ≤ v_p((k-1)!) + v_p(n + i·d)`.
-/
lemma per_prime {p n d k : ℕ} (hd : 1 ≤ d) (hnd : Nat.Coprime n d) (hk : 1 ≤ k)
    (hp : p.Prime) {e : ℕ} (hdvd : p ^ e ∣ apProd n d k) :
    ∃ i ∈ Finset.Icc 1 k,
      e ≤ (Nat.factorial (k - 1)).factorization p + (n + i * d).factorization p := by
  by_cases hpd : p ∣ d;
  · rcases e with ( _ | e ) <;> simp_all +decide [ Nat.factorization_eq_zero_of_not_dvd, Nat.Prime.dvd_iff_not_coprime ];
    · exact ⟨ 1, by norm_num, hk ⟩;
    · have := Nat.Prime.dvd_iff_not_coprime hp |>.1 ( dvd_trans ( dvd_pow_self _ ( Nat.succ_ne_zero _ ) ) hdvd );
      contrapose! this;
      refine' Nat.Coprime.prod_right fun i hi => _;
      refine' hp.coprime_iff_not_dvd.mpr _;
      intro h; have := Nat.dvd_gcd h ( show p ∣ d from hp.dvd_iff_not_coprime.mpr hpd ) ; aesop;
  · have := @LOA.basic_exists p d k hp hpd hk n;
    exact ⟨ this.choose, this.choose_spec.1, le_trans ( Nat.le_of_not_lt fun h => absurd ( Nat.dvd_trans ( pow_dvd_pow _ h ) hdvd ) ( Nat.pow_succ_factorization_not_dvd ( LOA.apProd_ne_zero hd n k ) hp ) ) this.choose_spec.2.2 ⟩

/-
**Per-prime consequence, full form.** As `per_prime`, but also returning that the
chosen index `i` is a `p`-adic argmax among the `k` terms.
-/
lemma per_prime_full {p n d k : ℕ} (hd : 1 ≤ d) (hnd : Nat.Coprime n d) (hk : 1 ≤ k)
    (hp : p.Prime) {e : ℕ} (hdvd : p ^ e ∣ apProd n d k) :
    ∃ i ∈ Finset.Icc 1 k,
      (∀ j ∈ Finset.Icc 1 k,
        (n + j * d).factorization p ≤ (n + i * d).factorization p) ∧
      e ≤ (Nat.factorial (k - 1)).factorization p + (n + i * d).factorization p := by
  by_cases hpd : p ∣ d;
  · -- If $p \mid d$, then for every $j$, $p \nmid (n + j \cdot d)$.
    have h_not_div : ∀ j ∈ Finset.Icc 1 k, ¬(p ∣ (n + j * d)) := by
      intro j hj H; have := Nat.dvd_gcd H hpd; aesop;
    have h_e_zero : e = 0 := by
      have h_e_zero : ¬(p ∣ apProd n d k) := by
        simp_all +decide [ Nat.Prime.dvd_iff_not_coprime hp ];
        exact Nat.Coprime.prod_right fun x hx => h_not_div x ( Finset.mem_Icc.mp hx |>.1 ) ( Finset.mem_Icc.mp hx |>.2 );
      exact Nat.eq_zero_of_not_pos fun h => h_e_zero <| dvd_trans ( dvd_pow_self _ h.ne' ) hdvd;
    use 1;
    simp_all +decide [ Nat.factorization_eq_zero_of_not_dvd ];
  · obtain ⟨ i, hi, hmax ⟩ := LOA.basic_exists hp hpd hk n;
    refine' ⟨ i, hi, hmax.1, le_trans _ hmax.2 ⟩;
    convert Nat.le_of_not_lt fun h => absurd ( Nat.dvd_trans ( pow_dvd_pow _ h ) hdvd ) ( Nat.pow_succ_factorization_not_dvd ( LOA.apProd_ne_zero ( by linarith ) n k ) hp ) using 1

/-
**Rearrangement lemma.** For a subset `I ⊆ {1,…,k}`, the product of the terms
`n + t·d` over `I` is at most the product over the `#I` largest indices.
-/
lemma prod_subset_le_topBlock {n d k : ℕ} {I : Finset ℕ}
    (hI : I ⊆ Finset.Icc 1 k) :
    ∏ t ∈ I, (n + t * d) ≤ ∏ t ∈ Finset.Icc (k - I.card + 1) k, (n + t * d) := by
  revert I;
  induction' k with k ih <;> simp_all +decide [ Finset.subset_iff ];
  · intro I hI; rw [ Finset.eq_empty_of_forall_notMem hI ] ; norm_num;
  · intro I hI; by_cases hI_empty : I = ∅; simp_all +decide ;
    -- Let M be the maximum element of I.
    obtain ⟨M, hM⟩ : ∃ M ∈ I, ∀ x ∈ I, x ≤ M := by
      exact ⟨ Finset.max' I ( Finset.nonempty_of_ne_empty hI_empty ), Finset.max'_mem _ _, fun x hx => Finset.le_max' _ _ hx ⟩;
    have hM_le_k : M ≤ k + 1 := by
      linarith [ hI hM.1 ]
    have hI'_subset : I.erase M ⊆ Finset.Icc 1 k := by
      grind
    have hI'_card : (I.erase M).card = I.card - 1 := by
      exact Finset.card_erase_of_mem hM.1
    have h_ind : ∏ t ∈ I.erase M, (n + t * d) ≤ ∏ t ∈ Finset.Icc (k - (I.card - 1) + 1) k, (n + t * d) := by
      exact hI'_card ▸ ih fun x hx => Finset.mem_Icc.mp ( hI'_subset hx ) |> fun h => ⟨ h.1, h.2 ⟩ ;
    have h_max : n + M * d ≤ n + (k + 1) * d := by
      exact Nat.add_le_add_left ( Nat.mul_le_mul_right _ hM_le_k ) _
    have h_prod : ∏ t ∈ I, (n + t * d) ≤ (n + (k + 1) * d) * ∏ t ∈ Finset.Icc (k - (I.card - 1) + 1) k, (n + t * d) := by
      rw [ ← Finset.mul_prod_erase _ _ hM.1 ] ; exact Nat.mul_le_mul h_max h_ind;
    have h_final : ∏ t ∈ Icc (k + 1 - I.card + 1) (k + 1), (n + t * d) = (n + (k + 1) * d) * ∏ t ∈ Finset.Icc (k - (I.card - 1) + 1) k, (n + t * d) := by
      erw [ Finset.prod_Ico_succ_top ] <;> norm_num [ Nat.sub_sub, add_comm ];
      · rw [ mul_comm ] ; rcases I with ⟨ ⟨ l, hl ⟩ ⟩ <;> aesop;
      · linarith [ Nat.sub_add_cancel ( show #I ≤ k + 1 from le_trans ( Finset.card_le_card ( show I ⊆ Finset.Icc 1 ( k + 1 ) from fun x hx => Finset.mem_Icc.mpr ( hI hx ) ) ) ( by norm_num ) ), show #I ≥ 1 from Finset.card_pos.mpr ⟨ M, hM.1 ⟩ ]
    exact h_prod.trans (h_final.ge)

/-
**The grouping crux.** Given, for each prime `p ∈ P`, an index `J p ∈ {1,…,k}`
and a power `p^(E p)` dividing the term `n + (J p)·d`, the product `∏ p^(E p)` is at
most the product of the `#P` largest terms.
-/
lemma prodPow_le_topProd {n d k : ℕ} (hd : 1 ≤ d) {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime)
    (hcard : P.card ≤ k) {E J : ℕ → ℕ}
    (hJ : ∀ p ∈ P, J p ∈ Finset.Icc 1 k)
    (hdvd : ∀ p ∈ P, p ^ (E p) ∣ (n + (J p) * d)) :
    (∏ p ∈ P, p ^ (E p)) ≤ topProd n d k P.card := by
  -- Let I := P.image J. Since ∀ p ∈ P, J p ∈ Finset.Icc 1 k, we have I ⊆ Finset.Icc 1 k, and I.card ≤ P.card (`Finset.card_image_le`).
  set I := P.image J with hI_def
  have hI_subset : I ⊆ Finset.Icc 1 k := by
    exact Finset.image_subset_iff.mpr hJ
  have hI_card : I.card ≤ P.card := by
    exact Finset.card_image_le;
  -- By `prod_primePow_dvd`, `∏ p ∈ P.filter (·), p^(E p) ∣ n + t*d`, hence `∏ p ∈ P.filter (·), p^(E p) ≤ n + t*d` by `Nat.le_of_dvd`.
  have h_div : ∀ t ∈ I, (∏ p ∈ P.filter (fun p => J p = t), p^(E p)) ≤ n + t * d := by
    intro t ht
    have h_div : (∏ p ∈ P.filter (fun p => J p = t), p^(E p)) ∣ n + t * d := by
      convert prod_primePow_dvd ( fun p hp => hP p <| Finset.mem_filter.mp hp |>.1 ) ?_ ?_ using 1;
      · nlinarith [ Finset.mem_Icc.mp ( hI_subset ht ) ];
      · grind +qlia;
    exact Nat.le_of_dvd ( by nlinarith [ Finset.mem_Icc.mp ( hI_subset ht ) ] ) h_div;
  -- By `prod_subset_le_topBlock`, `∏ t ∈ I, (n + t*d) ≤ ∏ t ∈ Finset.Icc (k - I.card + 1) k, (n + t*d)`.
  have h_prod_subset : ∏ t ∈ I, (n + t * d) ≤ ∏ t ∈ Finset.Icc (k - I.card + 1) k, (n + t * d) := by
    convert prod_subset_le_topBlock hI_subset using 1;
  convert le_trans _ ( h_prod_subset.trans _ ) using 1;
  · convert Finset.prod_le_prod' h_div using 1;
    rw [ Finset.prod_image' ] ; aesop;
  · refine' Finset.prod_le_prod_of_subset_of_one_le' _ _;
    · exact Finset.Icc_subset_Icc ( by omega ) le_rfl;
    · exact fun i hi₁ hi₂ => Nat.one_le_iff_ne_zero.mpr ( by nlinarith [ Finset.mem_Icc.mp hi₁ ] )

/-
**ELOA Principal Lemma** (product form, general `d`).  Let `P` be a finset of
distinct primes with `#P < k`, `gcd(n,d)=1`, `1 ≤ d`.  If `∏_{p∈P} p^(e p)` divides
`∏_{j=1}^k (n + j·d)`, then
`∏_{p∈P} p^(e p) ≤ (k-1)! · (product of the #P largest terms)`.
-/
theorem principal {n d k : ℕ} (hd : 1 ≤ d) (hnd : Nat.Coprime n d) (hk : 1 ≤ k)
    {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime) (hr : P.card < k)
    {e : ℕ → ℕ} (hdvd : (∏ p ∈ P, p ^ (e p)) ∣ apProd n d k) :
    (∏ p ∈ P, p ^ (e p)) ≤ Nat.factorial (k - 1) * topProd n d k P.card := by
  -- By `per_prime_full`, for each `p ∈ P` there is an index `J p ∈ {1,…,k}` such that `e p ≤ ((k-1)!).factorization p + (n + (J p)·d).factorization p`.
  obtain ⟨J, hJ⟩ : ∃ J : ℕ → ℕ, (∀ p ∈ P, J p ∈ Finset.Icc 1 k) ∧ (∀ p ∈ P, e p ≤ (Nat.factorization (Nat.factorial (k - 1))) p + (Nat.factorization (n + (J p) * d)) p) := by
    have hJ : ∀ p ∈ P, ∃ i ∈ Finset.Icc 1 k, e p ≤ (Nat.factorization (Nat.factorial (k - 1))) p + (Nat.factorization (n + i * d)) p := by
      intro p hp;
      apply per_prime hd hnd hk (hP p hp);
      exact dvd_trans ( by rw [ Finset.prod_eq_mul_prod_diff_singleton hp ] ; exact dvd_mul_right _ _ ) hdvd;
    choose! J hJ₁ hJ₂ using hJ; exact ⟨ J, hJ₁, hJ₂ ⟩ ;
  refine le_trans ?_ ( Nat.mul_le_mul_left _ <| prodPow_le_topProd ?_ ( fun p hp => hP p hp ) ( by linarith ) ( fun p hp => hJ.1 p hp ) ( fun p hp => Nat.ordProj_dvd _ _ ) );
  · refine' le_trans ( Finset.prod_le_prod' fun p hp => pow_le_pow_right₀ ( Nat.Prime.pos ( hP p hp ) ) ( hJ.2 p hp ) ) _;
    simp +decide [ pow_add, Finset.prod_mul_distrib ];
    exact Nat.mul_le_mul_right _ ( Nat.le_of_dvd ( Nat.factorial_pos _ ) ( prod_primePow_dvd ( fun p hp => hP p hp ) ( Nat.factorial_ne_zero _ ) fun p hp => Nat.ordProj_dvd _ _ ) );
  · linarith

/-
**ELOA for `d = 1`** (product form).  With `d = 1` the terms are the consecutive
integers `n+1, …, n+k`.  If `∏_{p∈P} p^(e p)` divides `∏_{j=1}^k (n + j)` then
`∏_{p∈P} p^(e p) ≤ k! · ∏_{i=1}^{#P} (n + k + 1 - i)`.
-/
theorem eloa_d1 {n k : ℕ} (hk : 1 ≤ k)
    {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime) (hr : P.card < k)
    {e : ℕ → ℕ} (hdvd : (∏ p ∈ P, p ^ (e p)) ∣ apProd n 1 k) :
    (∏ p ∈ P, p ^ (e p))
      ≤ Nat.factorial k * ∏ i ∈ Finset.Icc 1 P.card, (n + k + 1 - i) := by
  refine' le_trans ( principal _ _ _ hP hr hdvd ) _;
  · norm_num;
  · norm_num;
  · grind;
  · refine' Nat.mul_le_mul _ _;
    · exact Nat.factorial_le ( Nat.pred_le _ );
    · refine' le_of_eq _;
      refine' Finset.prod_bij ( fun i hi => k + 1 - i ) _ _ _ _ <;> norm_num;
      · omega;
      · intros; omega;
      · exact fun b hb₁ hb₂ => ⟨ k + 1 - b, ⟨ by omega, by omega ⟩, by omega ⟩;
      · intros; omega;

/-
**ELOA for LCM** (general `d`).  Let `P` be a finset of distinct primes with
`#P < k`, `gcd(n,d)=1`, `1 ≤ d`, and suppose each `p^(e p)` (`p ∈ P`) divides
`∏_{j=1}^k (n + j·d)`.  Then there is a choice of `p`-adic argmax indices `J p ∈
{1,…,k}` such that
`lcm_{p∈P} p^(e p) ≤ (lcm_{p∈P} [(k-1)!]_p) · (lcm_{p∈P} (n + (J p)·d))`,
where `[(k-1)!]_p = p^{v_p((k-1)!)}`.

(The hypothesis `#P < k` is kept because it is part of the stated law, but the LCM
form actually holds without it, so it appears as `_hr`.)
-/
theorem eloa_lcm {n d k : ℕ} (hd : 1 ≤ d) (hnd : Nat.Coprime n d) (hk : 1 ≤ k)
    {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime) (_hr : P.card < k)
    {e : ℕ → ℕ} (hdvd : ∀ p ∈ P, p ^ (e p) ∣ apProd n d k) :
    ∃ J : ℕ → ℕ,
      (∀ p ∈ P, J p ∈ Finset.Icc 1 k ∧
        ∀ j ∈ Finset.Icc 1 k,
          (n + j * d).factorization p ≤ (n + (J p) * d).factorization p) ∧
      Finset.lcm P (fun p => p ^ (e p))
        ≤ Finset.lcm P (fun p => p ^ ((Nat.factorial (k - 1)).factorization p))
          * Finset.lcm P (fun p => n + (J p) * d) := by
  choose! J hJ₁ hJ₂ hJ₃ using fun p hp => per_prime_full hd hnd hk ( hP p hp ) ( hdvd p hp );
  refine' ⟨ J, _, _ ⟩;
  · exact fun p hp => ⟨ hJ₁ p hp, hJ₂ p hp ⟩;
  · refine' Nat.le_of_dvd ( Nat.mul_pos ( Nat.pos_of_ne_zero _ ) ( Nat.pos_of_ne_zero _ ) ) _;
    · simp_all +decide [ Finset.lcm_eq_zero_iff ];
    · simp_all +decide [ Finset.lcm_eq_zero_iff ];
      exact fun p hp hn => ⟨ by linarith [ hJ₁ p hp ], by linarith ⟩;
    · refine' Finset.lcm_dvd fun p hp => _;
      refine' dvd_trans _ ( mul_dvd_mul ( Finset.dvd_lcm hp ) ( Finset.dvd_lcm hp ) );
      exact dvd_trans ( pow_dvd_pow _ ( hJ₃ p hp ) ) ( by rw [ pow_add ] ; exact mul_dvd_mul_left _ ( Nat.ordProj_dvd _ _ ) )

end LOA