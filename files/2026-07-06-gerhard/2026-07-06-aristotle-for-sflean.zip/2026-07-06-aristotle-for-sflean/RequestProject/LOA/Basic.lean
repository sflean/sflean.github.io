import RequestProject.LOA.Defs

/-!
# The basic result (Laws Of Ademption)

The **basic result**: let `p` be a prime with `p ∤ d`.  Among the `k` terms
`n + j·d` (`1 ≤ j ≤ k`) pick one, `n + i·d`, of maximal `p`-adic valuation
`e = v_p(n + i·d)`.  Let `f = v_p((k-1)!)`.  Then

`v_p( ∏_{j=1}^k (n + j·d) ) ≤ f + e`.

Equivalently, if `p^g ∣ ∏ (n + j·d)` then `p^g ∣ [(k-1)!]_p · (n + i·d)`.

The proof is a clean valuation count: for any `j ≠ i`,
`v_p(n + j·d) ≤ v_p(|i - j|)` (from the ultrametric inequality applied to the two
terms of maximal-vs-smaller valuation), and
`∑_{j ≠ i} v_p(|i - j|) = v_p((i-1)!) + v_p((k-i)!) ≤ v_p((k-1)!)`
because `(i-1)!·(k-i)! ∣ (k-1)!`.
-/

open scoped BigOperators
open Finset

namespace LOA

/-- From `p ∤ d` we get `d ≠ 0`, hence `1 ≤ d`. -/
lemma one_le_d_of_not_dvd {p d : ℕ} (hpd : ¬ p ∣ d) : 1 ≤ d := by
  rcases Nat.eq_zero_or_pos d with h | h
  · exact absurd (h ▸ dvd_zero p) hpd
  · exact h

/-
**Key ultrametric step.** If two terms `n + a·d` and `n + b·d` (`a < b`) of the
progression have `v_p(n+a·d) ≤ v_p(n+b·d)`, then `v_p(n+a·d) ≤ v_p(b - a)`.
Reason: with `m = v_p(n+a·d)`, we have `p^m ∣ n+a·d` and `p^m ∣ n+b·d`, hence
`p^m ∣ (n+b·d) - (n+a·d) = (b-a)·d`; since `p ∤ d`, `p^m` is coprime to `d`, so
`p^m ∣ b - a`.
-/
lemma factorization_le_of_two_terms {p n d a b : ℕ} (hp : p.Prime) (hpd : ¬ p ∣ d)
    (hab : a < b)
    (h : (n + a * d).factorization p ≤ (n + b * d).factorization p) :
    (n + a * d).factorization p ≤ (b - a).factorization p := by
  -- Since $p \mid (b - a)$, we have $p^{\text{Nat.factorization}(n + ad)p} \mid (b - a)$.
  have h_div : p ^ Nat.factorization (n + a * d) p ∣ (b - a) := by
    have h_div : p ^ (Nat.factorization (n + a * d) p) ∣ ((b - a) * d) := by
      have h_ultra : p ^ (Nat.factorization (n + a * d) p) ∣ (n + b * d) - (n + a * d) := by
        exact Nat.dvd_sub ( Nat.dvd_trans ( pow_dvd_pow _ h ) ( Nat.ordProj_dvd _ _ ) ) ( Nat.ordProj_dvd _ _ );
      convert h_ultra using 1 ; rw [ Nat.add_sub_add_left, ← tsub_mul ];
    exact ( Nat.Coprime.pow_left _ <| hp.coprime_iff_not_dvd.mpr hpd ) |> fun h => h.dvd_of_dvd_mul_right h_div;
  exact Nat.le_of_not_gt fun h' => absurd ( dvd_trans ( pow_dvd_pow _ h' ) h_div ) ( Nat.pow_succ_factorization_not_dvd ( Nat.sub_ne_zero_of_lt hab ) hp )

/-
The sum of `p`-adic valuations over `1 ≤ a ≤ m` equals `v_p(m!)`, since
`m! = ∏_{a=1}^m a`.
-/
lemma sum_factorization_Icc (p m : ℕ) :
    ∑ a ∈ Finset.Icc 1 m, (a).factorization p = (Nat.factorial m).factorization p := by
  induction' m with m ih <;> simp_all +decide [ Nat.factorial_succ, (Nat.succ_eq_succ ▸ Finset.Icc_succ_left_eq_Ioc) ];
  rw [ Finset.sum_Ioc_succ_top, Nat.factorization_mul ] <;> simp_all +decide [ Nat.factorial_ne_zero ];
  ring

/-
**The basic result** (valuation form).  Let `p` be a prime with `p ∤ d`, and let
`i` (`1 ≤ i ≤ k`) index a term `n + i·d` of maximal `p`-adic valuation among the `k`
terms.  Then the `p`-adic valuation of the product of all `k` terms is at most
`v_p((k-1)!) + v_p(n + i·d)`.
-/
theorem basic {p n d k : ℕ} (hp : p.Prime) (hpd : ¬ p ∣ d) (hk : 1 ≤ k)
    {i : ℕ} (hi : i ∈ Finset.Icc 1 k)
    (hmax : ∀ j ∈ Finset.Icc 1 k,
      (n + j * d).factorization p ≤ (n + i * d).factorization p) :
    (apProd n d k).factorization p
      ≤ (Nat.factorial (k - 1)).factorization p + (n + i * d).factorization p := by
  have h_split : ∑ j ∈ Finset.Icc 1 k \ {i}, (n + j * d).factorization p ≤ ∑ j ∈ Finset.Icc 1 (i - 1), (i - j).factorization p + ∑ j ∈ Finset.Icc (i + 1) k, (j - i).factorization p := by
    have h_split : ∑ j ∈ Finset.Icc 1 k \ {i}, (n + j * d).factorization p ≤ ∑ j ∈ Finset.Icc 1 (i - 1), (n + j * d).factorization p + ∑ j ∈ Finset.Icc (i + 1) k, (n + j * d).factorization p := by
      rw [ ← Finset.sum_union ];
      · refine Finset.sum_le_sum_of_subset ?_;
        grind;
      · exact Finset.disjoint_left.mpr fun x hx₁ hx₂ => by linarith [ Finset.mem_Icc.mp hx₁, Finset.mem_Icc.mp hx₂, Nat.sub_add_cancel ( Finset.mem_Icc.mp hi |>.1 ) ] ;
    refine le_trans h_split <| add_le_add ?_ ?_;
    · refine Finset.sum_le_sum fun j hj => ?_;
      convert factorization_le_of_two_terms hp hpd ( show j < i from lt_of_le_of_lt ( Finset.mem_Icc.mp hj |>.2 ) ( Nat.pred_lt ( ne_bot_of_gt ( Finset.mem_Icc.mp hi |>.1 ) ) ) ) ( hmax j <| Finset.mem_Icc.mpr ⟨ Finset.mem_Icc.mp hj |>.1, le_trans ( Finset.mem_Icc.mp hj |>.2 ) ( Nat.pred_le _ ) |> le_trans <| Finset.mem_Icc.mp hi |>.2 ⟩ ) using 1;
    · gcongr;
      rename_i j hj;
      have h_div : p ^ (Nat.factorization (n + j * d) p) ∣ (j - i) * d := by
        have h_div : p ^ (Nat.factorization (n + j * d) p) ∣ (n + j * d) ∧ p ^ (Nat.factorization (n + j * d) p) ∣ (n + i * d) := by
          exact ⟨ Nat.ordProj_dvd _ _, Nat.dvd_trans ( pow_dvd_pow _ ( hmax j ( Finset.Icc_subset_Icc ( by linarith ) le_rfl hj ) ) ) ( Nat.ordProj_dvd _ _ ) ⟩;
        convert Nat.dvd_sub h_div.1 h_div.2 using 1 ; rw [ Nat.add_sub_add_left ] ; rw [ tsub_mul ];
      have h_div : p ^ (Nat.factorization (n + j * d) p) ∣ (j - i) := by
        exact ( Nat.Coprime.dvd_of_dvd_mul_right ( show Nat.Coprime ( p ^ ( Nat.factorization ( n + j * d ) p ) ) d from Nat.Coprime.pow_left _ <| hp.coprime_iff_not_dvd.mpr hpd ) h_div );
      exact Nat.le_of_not_lt fun h => absurd ( Nat.dvd_trans ( pow_dvd_pow _ h ) h_div ) ( Nat.pow_succ_factorization_not_dvd ( Nat.sub_ne_zero_of_lt ( by linarith [ Finset.mem_Icc.mp hj ] ) ) hp );
  -- Reindex the difference sums to factorials:
  have h_reindex : ∑ j ∈ Finset.Icc 1 (i - 1), (i - j).factorization p + ∑ j ∈ Finset.Icc (i + 1) k, (j - i).factorization p = ∑ j ∈ Finset.Icc 1 (i - 1), (j).factorization p + ∑ j ∈ Finset.Icc 1 (k - i), (j).factorization p := by
    refine' congrArg₂ ( · + · ) _ _;
    · apply Finset.sum_bij (fun j hj => i - j);
      · grind;
      · grind;
      · exact fun x hx => ⟨ i - x, Finset.mem_Icc.mpr ⟨ Nat.sub_pos_of_lt <| Finset.mem_Icc.mp hx |>.2.trans_lt <| Nat.pred_lt <| ne_bot_of_gt <| Finset.mem_Icc.mp hi |>.1, Nat.sub_le_sub_left ( Finset.mem_Icc.mp hx |>.1 ) _ ⟩, Nat.sub_sub_self <| Finset.mem_Icc.mp hx |>.2.trans <| Nat.pred_le _ ⟩;
      · grind;
    · apply Finset.sum_bij (fun j hj => j - i);
      · grind;
      · grind;
      · exact fun b hb => ⟨ i + b, Finset.mem_Icc.mpr ⟨ by linarith [ Finset.mem_Icc.mp hb ], by linarith [ Finset.mem_Icc.mp hb, Nat.sub_add_cancel ( show i ≤ k from Finset.mem_Icc.mp hi |>.2 ) ] ⟩, by simp +decide ⟩;
      · grind;
  -- Combine factorials:
  have h_combine : ∑ j ∈ Finset.Icc 1 (i - 1), (j).factorization p + ∑ j ∈ Finset.Icc 1 (k - i), (j).factorization p ≤ (Nat.factorial (k - 1)).factorization p := by
    have h_combine : ∑ j ∈ Finset.Icc 1 (i - 1), (j).factorization p + ∑ j ∈ Finset.Icc 1 (k - i), (j).factorization p ≤ (Nat.factorial (i - 1) * Nat.factorial (k - i)).factorization p := by
      rw [ Nat.factorization_mul ] <;> norm_num [ Nat.factorial_ne_zero ];
      exact add_le_add ( by rw [ ← sum_factorization_Icc ] ) ( by rw [ ← sum_factorization_Icc ] );
    refine le_trans h_combine ?_;
    exact Nat.factorization_le_iff_dvd ( by positivity ) ( by positivity ) |>.2 ( Nat.factorial_mul_factorial_dvd_factorial_add _ _ |> dvd_trans <| Nat.factorial_dvd_factorial <| by cases k <;> cases i <;> norm_num at * ; omega ) p;
  have h_factorization_prod : (apProd n d k).factorization p = ∑ j ∈ Finset.Icc 1 k, (n + j * d).factorization p := by
    unfold apProd; rw [ Nat.factorization_prod ] ; aesop;
    exact fun x hx => by nlinarith [ Finset.mem_Icc.mp hx, show d > 0 from Nat.pos_of_ne_zero ( by aesop_cat ) ] ;
  rw [ Finset.sum_eq_add_sum_diff_singleton hi ] at h_factorization_prod ; linarith

/-
**The basic result, packaged form.** For a prime `p` with `p ∤ d` and `1 ≤ k`,
there is a term index `i` (`1 ≤ i ≤ k`) of maximal `p`-adic valuation such that the
valuation of the product of all `k` terms is at most `v_p((k-1)!) + v_p(n + i·d)`.
-/
theorem basic_exists {p d k : ℕ} (hp : p.Prime) (hpd : ¬ p ∣ d) (hk : 1 ≤ k) (n : ℕ) :
    ∃ i ∈ Finset.Icc 1 k,
      (∀ j ∈ Finset.Icc 1 k,
        (n + j * d).factorization p ≤ (n + i * d).factorization p) ∧
      (apProd n d k).factorization p
        ≤ (Nat.factorial (k - 1)).factorization p + (n + i * d).factorization p := by
  -- The set `Finset.Icc 1 k` is nonempty because `1 ≤ k` (so `1 ∈ Finset.Icc 1 k`).
  have h_nonempty : Finset.Nonempty (Finset.Icc 1 k) := by
    exact ⟨ 1, Finset.mem_Icc.mpr ⟨ by norm_num, hk ⟩ ⟩;
  exact Exists.elim ( Finset.exists_max_image _ _ h_nonempty ) fun i hi => ⟨ i, hi.1, fun j hj => hi.2 j hj, basic hp hpd hk hi.1 hi.2 ⟩

end LOA