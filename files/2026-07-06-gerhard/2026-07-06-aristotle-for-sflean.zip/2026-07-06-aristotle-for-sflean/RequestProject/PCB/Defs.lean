import Mathlib

/-!
# Definitions for the Prime Counting Bounds (PCB)

We study bounds on the prime counting function
`π(k) = #{ p : p prime and p ≤ k }`.

We prove, in two independent ways, that

* `π(k) ≤ a(k)` where `a(k) = ⌈k/2⌉`, and
* `π(k) ≤ b(k)` where `b(k) = 1 + ⌈k/3⌉`.

**Way I** is a sieve / counting-function argument built on three prime-free sets
`UNO = {1}`, `DOS = {2n : n > 1}`, `TRES = {3(2n+1) : n > 0}`.

**Way II** is an inductive / parity argument.

This file collects all the definitions; the two ways live in
`RequestProject.PCB.WayI` and `RequestProject.PCB.WayII`, and are indexed in
`RequestProject.PCB.Main`.
-/

open scoped BigOperators
open Finset

namespace PCB

/-- The prime counting function `π(k) = #{ p ≤ k : p prime }`. -/
def piCount (k : ℕ) : ℕ := ((Finset.Icc 1 k).filter Nat.Prime).card

/-- `a(k) = ⌈k/2⌉`, realised as `(k+1)/2` in natural-number division. -/
def boundA (k : ℕ) : ℕ := (k + 1) / 2

/-- `b(k) = 1 + ⌈k/3⌉`, realised as `1 + (k+2)/3` in natural-number division. -/
def boundB (k : ℕ) : ℕ := 1 + (k + 2) / 3

/-- `UNO = {1}`. -/
def UNO : Set ℕ := {1}

/-- `DOS = {2n : n > 1}` (the even numbers `> 2`). -/
def DOS : Set ℕ := {m | ∃ n, 1 < n ∧ m = 2 * n}

/-- `TRES = {3(2n+1) : n > 0}` (the odd multiples of `3` that are `> 3`). -/
def TRES : Set ℕ := {m | ∃ n, 0 < n ∧ m = 3 * (2 * n + 1)}

/-- Decidable characterisation of `DOS`: `m` is even and `> 2`. -/
def dosP (m : ℕ) : Prop := 2 < m ∧ 2 ∣ m

/-- Decidable characterisation of `TRES`: `m ≡ 3 (mod 6)` and `m > 3`. -/
def tresP (m : ℕ) : Prop := 3 < m ∧ m % 6 = 3

instance : DecidablePred dosP := fun m => by unfold dosP; infer_instance
instance : DecidablePred tresP := fun m => by unfold tresP; infer_instance

/-- Membership in `UNO`. -/
@[simp] lemma mem_UNO {m : ℕ} : m ∈ UNO ↔ m = 1 := Iff.rfl

/-
`DOS` is exactly the set of even numbers `> 2`.
-/
lemma mem_DOS {m : ℕ} : m ∈ DOS ↔ dosP m := by
  constructor <;> intro h;
  · rcases h with ⟨ n, hn, rfl ⟩ ; exact ⟨ by linarith, by norm_num ⟩;
  · exact ⟨ m / 2, by linarith [ Nat.div_mul_cancel h.2, h.1 ], by linarith [ Nat.div_mul_cancel h.2 ] ⟩

/-
`TRES` is exactly the set of numbers `≡ 3 (mod 6)` that are `> 3`.
-/
lemma mem_TRES {m : ℕ} : m ∈ TRES ↔ tresP m := by
  constructor;
  · rintro ⟨ n, hn, rfl ⟩ ; exact ⟨ by linarith, by omega ⟩;
  · rintro ⟨ h3, h6 ⟩;
    exact ⟨ m / 6, by omega, by omega ⟩

/-- Counting function of `UNO ∪ DOS` on `[1,k]`. -/
def cntUD (k : ℕ) : ℕ := ((Finset.Icc 1 k).filter (fun m => m = 1 ∨ dosP m)).card

/-- Counting function of `UNO ∪ DOS ∪ TRES` on `[1,k]`. -/
def cntUDT (k : ℕ) : ℕ :=
  ((Finset.Icc 1 k).filter (fun m => m = 1 ∨ dosP m ∨ tresP m)).card

/-- Counting function of `TRES` on `[1,k]`. -/
def cntTRES (k : ℕ) : ℕ := ((Finset.Icc 1 k).filter tresP).card

/-- Counting function of the complement of `UNO ∪ DOS` on `[1,k]`. -/
def compUD (k : ℕ) : ℕ :=
  ((Finset.Icc 1 k).filter (fun m => ¬ (m = 1 ∨ dosP m))).card

/-- Counting function of the complement of `UNO ∪ DOS ∪ TRES` on `[1,k]`. -/
def compUDT (k : ℕ) : ℕ :=
  ((Finset.Icc 1 k).filter (fun m => ¬ (m = 1 ∨ dosP m ∨ tresP m))).card

/-! ## Faithfulness lemmas: the three sets are prime-free and distinct -/

/-
`UNO` contains no prime.
-/
lemma no_prime_UNO {p : ℕ} (hp : p.Prime) : p ∉ UNO := by
  simp [UNO, hp.ne_one]

/-
`DOS` contains no prime.
-/
lemma no_prime_DOS {p : ℕ} (hp : p.Prime) : p ∉ DOS := by
  rintro ⟨ n, hn, rfl ⟩;
  simp_all +decide [ Nat.prime_mul_iff ]

/-
`TRES` contains no prime.
-/
lemma no_prime_TRES {p : ℕ} (hp : p.Prime) : p ∉ TRES := by
  rintro ⟨ n, hn, rfl ⟩;
  simp_all +decide [ Nat.prime_mul_iff ]

/-
The union `UNO ∪ DOS ∪ TRES` contains no prime.
-/
lemma no_prime_union {p : ℕ} (hp : p.Prime) : p ∉ UNO ∪ DOS ∪ TRES := by
  simp +zetaDelta at *;
  exact ⟨ ⟨ hp.ne_one, no_prime_DOS hp ⟩, no_prime_TRES hp ⟩

/-
`UNO` and `DOS` are disjoint.
-/
lemma UNO_DOS_disjoint : Disjoint UNO DOS := by
  exact Set.disjoint_left.mpr fun x hx₁ hx₂ => by obtain ⟨ n, hn, rfl ⟩ := hx₂; linarith [ Set.mem_singleton_iff.mp hx₁ ] ;

/-
`UNO` and `TRES` are disjoint.
-/
lemma UNO_TRES_disjoint : Disjoint UNO TRES := by
  exact Set.disjoint_left.mpr fun x hx₁ hx₂ => by obtain ⟨ n, hn, rfl ⟩ := hx₂; linarith [ Set.mem_singleton_iff.mp hx₁ ] ;

/-
`DOS` and `TRES` are disjoint.
-/
lemma DOS_TRES_disjoint : Disjoint DOS TRES := by
  exact Set.disjoint_left.mpr fun m h₁ h₂ => by obtain ⟨ n, hn, rfl ⟩ := h₁; obtain ⟨ n', hn', heq ⟩ := h₂; omega;

end PCB