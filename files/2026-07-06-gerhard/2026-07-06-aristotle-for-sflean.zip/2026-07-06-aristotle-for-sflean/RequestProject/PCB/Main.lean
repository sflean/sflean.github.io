import RequestProject.PCB.WayI
import RequestProject.PCB.WayII

/-!
# Prime Counting Bounds (PCB) — top-level index

This project formally verifies the bounds
`π(k) ≤ a(k) = ⌈k/2⌉` and `π(k) ≤ b(k) = 1 + ⌈k/3⌉`
on the prime counting function, each in two independent ways.

## Definitions (`RequestProject/PCB/Defs.lean`)

* `PCB.piCount k = #{p ≤ k : p prime}`
* `PCB.boundA k = ⌈k/2⌉`,  `PCB.boundB k = 1 + ⌈k/3⌉`
* `PCB.UNO = {1}`, `PCB.DOS = {2n : n>1}`, `PCB.TRES = {3(2n+1) : n>0}`
* prime-free/disjointness lemmas: `PCB.no_prime_union`, `PCB.UNO_DOS_disjoint`, …

## Way I — sieve / counting functions (`RequestProject/PCB/WayI.lean`)

* `PCB.cntUD_eq`, `PCB.cntTRES_eq`, `PCB.cntUDT_eq` — the counting functions
* `PCB.compUD_eq_boundA`, `PCB.compUD_le_boundA`, `PCB.compUDT_le_boundB`
* `PCB.pi_le_compUD`, `PCB.pi_le_compUDT` — primes sit in the complements
* `PCB.pi_le_a_wayI`, `PCB.pi_le_b_wayI`

## Way II — induction / parity (`RequestProject/PCB/WayII.lean`)

* `PCB.pi_add_two_le` : `π(k+2) ≤ π(k)+1`
* `PCB.pi_three_mul_succ_eq` : `π(3(k+1)) = π(3k+2)`
* `PCB.pi_three_step` : `π(3k+3) ≤ 1 + π(3k)`
* `PCB.pi_le_a_wayII`, `PCB.pi_le_b_wayII`

## Final results
-/

namespace PCB

/-- `π(k) ≤ a(k) = ⌈k/2⌉` for all `k`. -/
theorem pi_le_a (k : ℕ) : piCount k ≤ boundA k := pi_le_a_wayI k

/-- `π(k) ≤ b(k) = 1 + ⌈k/3⌉` for all `k`. -/
theorem pi_le_b (k : ℕ) : piCount k ≤ boundB k := pi_le_b_wayI k

end PCB
