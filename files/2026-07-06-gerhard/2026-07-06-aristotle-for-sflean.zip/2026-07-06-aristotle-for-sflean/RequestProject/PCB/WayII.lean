import RequestProject.PCB.Defs

/-!
# Way II: the inductive / parity proof of `π(k) ≤ a(k)` and `π(k) ≤ b(k)`

We use that of two consecutive integers one is even (hence, if `> 2`, composite),
and that a multiple of `3` bigger than `3` is composite.
-/

open scoped BigOperators
open Finset

namespace PCB

/-
Of every two extra integers `k+1, k+2` at most one is prime, so the prime
count grows by at most one when `k` increases by two (`k ≥ 2`).
-/
theorem pi_add_two_le (k : ℕ) (hk : 2 ≤ k) : piCount (k + 2) ≤ piCount k + 1 := by
  -- By definition of `piCount`, we have:
  unfold piCount;
  rw [ show Icc 1 ( k + 2 ) = Icc 1 k ∪ { ( k + 1 ), ( k + 2 ) } from ?_, Finset.filter_union ];
  · by_cases h : Nat.Prime ( k + 1 ) <;> by_cases h' : Nat.Prime ( k + 2 ) <;> simp_all +decide [ Finset.filter_insert, Finset.filter_singleton ];
    cases Nat.Prime.eq_two_or_odd h <;> cases Nat.Prime.eq_two_or_odd h' <;> simp_all +arith +decide [ Nat.add_mod ];
  · grind

/-
**Way II:** `π(k) ≤ a(k) = ⌈k/2⌉` for all `k`.
-/
theorem pi_le_a_wayII (k : ℕ) : piCount k ≤ boundA k := by
  induction' k using Nat.strong_induction_on with k ih;
  rcases k with ( _ | _ | _ | _ | k ) <;> simp +arith +decide [ * ] at *;
  exact le_trans ( pi_add_two_le _ ( by linarith ) ) ( by specialize ih ( k + 2 ) ( by linarith ) ; norm_num [ boundA ] at * ; omega )

/-
`3(k+1)` is composite for `k > 0`, so adding it does not change the prime
count: `π(3(k+1)) = π(3k+2)`.
-/
theorem pi_three_mul_succ_eq (k : ℕ) (hk : 0 < k) :
    piCount (3 * (k + 1)) = piCount (3 * k + 2) := by
      convert Finset.card_filter ( fun m => Nat.Prime m ) ( Finset.Icc 1 ( 3 * ( k + 1 ) ) ) using 2;
      erw [ Finset.sum_Ico_succ_top ] <;> norm_num [ Nat.mul_succ, Finset.sum_Ico_succ_top ];
      rw [ if_neg ( by rw [ show 3 * k + 3 = 3 * ( k + 1 ) by ring ] ; exact Nat.not_prime_mul ( by norm_num ) ( by linarith ) ) ] ; rfl

/-
For `k > 0`, `π(3k+3) ≤ 1 + π(3k)`.
-/
theorem pi_three_step (k : ℕ) (hk : 0 < k) :
    piCount (3 * k + 3) ≤ 1 + piCount (3 * k) := by
      convert pi_add_two_le ( 3 * k ) _ using 1;
      · convert pi_three_mul_succ_eq k hk using 1;
      · grobner;
      · grind

/-
Helper: `π(3j) ≤ 1 + j`, i.e. `π(3j) ≤ b(3j)`.
-/
theorem pi_mul_three_le (j : ℕ) : piCount (3 * j) ≤ 1 + j := by
  induction' j with j ih <;> simp_all +arith +decide [ Nat.mul_succ ];
  by_cases hj : 0 < j <;> simp_all +arith +decide;
  linarith [ pi_three_step j hj ]

/-
**Way II:** `π(k) ≤ b(k) = 1 + ⌈k/3⌉` for all `k`.
-/
theorem pi_le_b_wayII (k : ℕ) : piCount k ≤ boundB k := by
  -- By definition of $boundB$, we have $boundB k = 1 + (k + 2) / 3$.
  unfold piCount boundB;
  -- Consider two cases: $k \leq 2$ and $k > 2$.
  by_cases hk : k ≤ 2;
  · native_decide +revert;
  · -- Let $j := k / 3$ and $r := k % 3$, so $k = 3j + r$ with $r < 3$.
    obtain ⟨j, r, hr⟩ : ∃ j r, k = 3 * j + r ∧ r < 3 := by
      exact ⟨ k / 3, k % 3, by rw [ Nat.div_add_mod ], Nat.mod_lt _ <| by decide ⟩;
    rcases hr with ⟨ rfl, hr ⟩ ; interval_cases r <;> simp +arith +decide at hk ⊢;
    · convert pi_mul_three_le j using 1 ; norm_num [ Nat.add_div ] ; ring;
    · -- Since $3j + 1 \leq 3j + 2$, we have $\pi(3j + 1) \leq \pi(3j + 2)$.
      have h_pi_le : piCount (3 * j + 1) ≤ piCount (3 * j + 2) := by
        exact Finset.card_mono <| Finset.filter_subset_filter _ <| Finset.Icc_subset_Icc_right <| Nat.le_succ _;
      exact h_pi_le.trans ( by have := pi_add_two_le ( 3 * j ) ( by linarith ) ; have := pi_mul_three_le j; norm_num [ piCount ] at *; omega );
    · -- Apply the lemma `pi_add_two_le` to get `piCount (3 * j + 2) ≤ piCount (3 * j) + 1`.
      have h_pi_add_two : piCount (3 * j + 2) ≤ piCount (3 * j) + 1 := by
        exact pi_add_two_le _ ( by linarith [ Nat.pos_of_ne_zero hk ] );
      exact h_pi_add_two.trans ( by have := pi_mul_three_le j; norm_num [ Nat.add_div ] at *; linarith )

end PCB