import RequestProject.PCB.Defs

/-!
# Way I: the sieve / counting-function proof of `π(k) ≤ a(k)` and `π(k) ≤ b(k)`

The primes are contained in the complement of the prime-free sets
`UNO ∪ DOS` (resp. `UNO ∪ DOS ∪ TRES`).  We compute the counting functions of
these unions, deduce the complement counting functions, and conclude the bounds.
-/

open scoped BigOperators
open Finset

namespace PCB

/-! ### Counting functions of the sieve sets -/

/-
The counting function of `UNO ∪ DOS` on `[1,k]` equals `⌊k/2⌋` for `k ≥ 2`.
-/
lemma cntUD_eq (k : ℕ) (hk : 2 ≤ k) : cntUD k = k / 2 := by
  induction hk <;> simp_all +decide [ (Nat.succ_eq_succ ▸ Finset.Icc_succ_left_eq_Ioc), cntUD ];
  rw [ Finset.card_filter ] at *;
  rw [ Finset.sum_Ioc_succ_top ] <;> simp_all +arith +decide;
  unfold dosP; split_ifs <;> omega;

/-
The counting function of `TRES` on `[1,k]` equals `⌊(k-3)/6⌋`.
-/
lemma cntTRES_eq (k : ℕ) : cntTRES k = (k - 3) / 6 := by
  induction' k with k ih <;> simp_all +arith +decide [ (Nat.succ_eq_succ ▸ Finset.Icc_succ_left_eq_Ioc), cntTRES ];
  by_cases hk : k < 3;
  · interval_cases k <;> simp_all +decide
  · rw [ Finset.card_filter ] at *;
    rw [ Finset.sum_Ioc_succ_top ( by linarith ), ih ];
    unfold tresP; split_ifs <;> omega;

/-
Since `UNO ∪ DOS` and `TRES` are disjoint, their counting functions add.
-/
lemma cntUDT_eq (k : ℕ) : cntUDT k = cntUD k + cntTRES k := by
  unfold cntUDT cntUD cntTRES;
  rw [ ← Finset.card_union_of_disjoint ];
  · congr with m ; aesop;
  · simp +contextual [ Finset.disjoint_left, dosP, tresP ];
    omega

/-! ### Complement counting functions -/

/-
The complement and the set partition `[1,k]` (which has `k` elements).
-/
lemma compUD_add_cntUD (k : ℕ) : compUD k + cntUD k = k := by
  unfold compUD cntUD;
  rw [ add_comm, Finset.card_filter_add_card_filter_not ] ; aesop

/-
The complement and the set partition `[1,k]` (which has `k` elements).
-/
lemma compUDT_add_cntUDT (k : ℕ) : compUDT k + cntUDT k = k := by
  rw [ add_comm, compUDT, cntUDT ];
  rw [ Finset.card_filter, Finset.card_filter ];
  rw [ ← Finset.sum_add_distrib, Finset.sum_congr rfl fun x hx => by aesop, Finset.sum_const, Finset.card_eq_sum_ones ] ; norm_num

/-
For `k ≥ 2`, the complement counting function of `UNO ∪ DOS` equals `a(k)`.
-/
lemma compUD_eq_boundA (k : ℕ) (hk : 2 ≤ k) : compUD k = boundA k := by
  rw [ eq_comm ] ; unfold boundA; rw [ show compUD k = k - cntUD k from eq_tsub_of_add_eq <| compUD_add_cntUD k ] ; ( rw [ cntUD_eq k hk ] ) ; omega;

/-
The complement counting function of `UNO ∪ DOS` is at most `a(k)`, for all `k`.
-/
lemma compUD_le_boundA (k : ℕ) : compUD k ≤ boundA k := by
  rcases k with ( _ | _ | k ) <;> simp +arith +decide [ * ];
  exact compUD_eq_boundA _ ( Nat.le_add_left _ _ ) ▸ le_rfl

/-
The complement counting function of `UNO ∪ DOS ∪ TRES` is at most `b(k)`, for all `k`.
-/
lemma compUDT_le_boundB (k : ℕ) : compUDT k ≤ boundB k := by
  rcases k with ( _ | _ | _ | _ | _ | k ) <;> simp_all +arith +decide [ boundB ];
  rw [ show compUDT ( k + 5 ) = ( k + 5 ) - ( cntUD ( k + 5 ) + cntTRES ( k + 5 ) ) from ?_ ];
  · grind +suggestions;
  · exact eq_tsub_of_add_eq ( by linarith [ compUDT_add_cntUDT ( k + 5 ), cntUDT_eq ( k + 5 ) ] )

/-! ### Primes sit inside the complements -/

/-
Every prime `≤ k` lies in the complement of `UNO ∪ DOS`.
-/
lemma pi_le_compUD (k : ℕ) : piCount k ≤ compUD k := by
  refine Finset.card_mono ?_;
  intro m hm; simp_all +decide [ dosP ];
  exact ⟨ hm.2.ne_one, fun h => hm.2.eq_two_or_odd.resolve_left h.ne' ⟩

/-
Every prime `≤ k` lies in the complement of `UNO ∪ DOS ∪ TRES`.
-/
lemma pi_le_compUDT (k : ℕ) : piCount k ≤ compUDT k := by
  -- Apply the subset relationship and cardinality inequality.
  apply Finset.card_le_card;
  intro m hm; simp_all +decide [ dosP, tresP ] ;
  exact ⟨ hm.2.ne_one, fun h => hm.2.eq_two_or_odd.resolve_left ( by linarith ), fun h => fun h' => by have := Nat.dvd_of_mod_eq_zero ( show m % 3 = 0 by omega ) ; rw [ hm.2.dvd_iff_eq ] at this <;> linarith ⟩

/-! ### The bounds -/

/-- **Way I:** `π(k) ≤ a(k) = ⌈k/2⌉` for all `k`. -/
theorem pi_le_a_wayI (k : ℕ) : piCount k ≤ boundA k :=
  le_trans (pi_le_compUD k) (compUD_le_boundA k)

/-- **Way I:** `π(k) ≤ b(k) = 1 + ⌈k/3⌉` for all `k`. -/
theorem pi_le_b_wayI (k : ℕ) : piCount k ≤ boundB k :=
  le_trans (pi_le_compUDT k) (compUDT_le_boundB k)

end PCB