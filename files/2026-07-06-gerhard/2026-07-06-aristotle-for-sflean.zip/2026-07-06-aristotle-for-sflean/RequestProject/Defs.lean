import Mathlib

/-!
# Definitions for the prime / binomial bound comparisons

Let `k` be a natural number and `hc k = ⌈k/2⌉`.  We study five quantities:

* `A k` – the product of the primes `p` with `hc k < p ≤ k`;
* `B k` – the product of the *distinct* primes `p` such that some power `p^e`
  (with `e ≥ 1`) satisfies `hc k < p^e ≤ k`;
* `C k = C(k, ⌈k/2⌉)` – the (central) binomial coefficient;
* `D k = 4^(k - ⌈k/2⌉) = 4^⌊k/2⌋`;
* `E k = C(2⌈k/2⌉, ⌈k/2⌉)` – a central binomial coefficient.

We also study the iterated products `AA, BB, CC, DD, EE` along the chain
`j₀ = k`, `j_{i+1} = hc (j_i)`.
-/

open scoped BigOperators
open Finset

namespace Bounds

/-- `hc k = ⌈k/2⌉`, realised as `(k+1)/2` in natural-number division. -/
def hc (k : ℕ) : ℕ := (k + 1) / 2

/-- The set of primes `p` with `hc k < p ≤ k`. -/
def Aset (k : ℕ) : Finset ℕ := (Finset.Ioc (hc k) k).filter Nat.Prime

/-- `A k` – product of the primes `p` with `hc k < p ≤ k`. -/
def A (k : ℕ) : ℕ := ∏ p ∈ Aset k, p

/-- The predicate defining the primes contributing to `B k`: `p` is prime and some
power `p^e` with `1 ≤ e ≤ k` satisfies `hc k < p^e ≤ k`. -/
def Bpred (k p : ℕ) : Prop :=
  Nat.Prime p ∧ ∃ e ∈ Finset.Icc 1 k, hc k < p ^ e ∧ p ^ e ≤ k

instance (k p : ℕ) : Decidable (Bpred k p) := by
  unfold Bpred; infer_instance

/-- The set of primes contributing to `B k`. -/
def Bset (k : ℕ) : Finset ℕ := (Finset.range (k + 1)).filter (Bpred k)

/-- `B k` – product of the distinct primes `p` such that some power `p^e`
(`e ≥ 1`) lies in `(hc k, k]`. -/
def B (k : ℕ) : ℕ := ∏ p ∈ Bset k, p

/-- `C k = C(k, ⌈k/2⌉)`. -/
def C (k : ℕ) : ℕ := Nat.choose k (hc k)

/-- `D k = 4^(k - ⌈k/2⌉) = 4^⌊k/2⌋`. -/
def D (k : ℕ) : ℕ := 4 ^ (k - hc k)

/-- `E k = C(2⌈k/2⌉, ⌈k/2⌉)`. -/
def E (k : ℕ) : ℕ := Nat.choose (2 * hc k) (hc k)

/-- The chain `j₀ = k`, `j_{i+1} = hc (j_i)`: `chain k i = hc^[i] k`. -/
def chain (k i : ℕ) : ℕ := hc^[i] k

/-- Iterated product of `A` along the chain: `AA k r = ∏_{i<r} A (jᵢ)`. -/
def AA (k r : ℕ) : ℕ := ∏ i ∈ Finset.range r, A (chain k i)

/-- Iterated product of `B` along the chain. -/
def BB (k r : ℕ) : ℕ := ∏ i ∈ Finset.range r, B (chain k i)

/-- Iterated product of `C` along the chain. -/
def CC (k r : ℕ) : ℕ := ∏ i ∈ Finset.range r, C (chain k i)

/-- Iterated product of `D` along the chain. -/
def DD (k r : ℕ) : ℕ := ∏ i ∈ Finset.range r, D (chain k i)

/-- Iterated product of `E` along the chain. -/
def EE (k r : ℕ) : ℕ := ∏ i ∈ Finset.range r, E (chain k i)

end Bounds
