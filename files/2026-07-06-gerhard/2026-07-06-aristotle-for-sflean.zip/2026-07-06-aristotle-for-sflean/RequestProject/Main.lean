import RequestProject.Products

/-!
# Prime / binomial bound comparisons — top-level index

This project formally verifies (or refutes) all pairwise comparisons between the
quantities `A, B, C, D, E` and their iterated products `AA, BB, CC, DD, EE`.

## Definitions (`RequestProject/Defs.lean`)

* `Bounds.hc k = ⌈k/2⌉`
* `Bounds.A k` – product of primes `p` with `hc k < p ≤ k`
* `Bounds.B k` – product of distinct primes `p` such that some power `p^e`
  (`e ≥ 1`) satisfies `hc k < p^e ≤ k`
* `Bounds.C k = C(k, ⌈k/2⌉)`
* `Bounds.D k = 4^(k - ⌈k/2⌉) = 4^⌊k/2⌋`
* `Bounds.E k = C(2⌈k/2⌉, ⌈k/2⌉)`
* `Bounds.chain k i = hc^[i] k` and the products `AA, BB, CC, DD, EE`.

## Single-index comparisons (`RequestProject/SingleIndex.lean`)

* `Bounds.A_le_B`, `Bounds.A_le_C`, `Bounds.A_le_D`, `Bounds.A_le_E`
* `Bounds.B_le_C`, `Bounds.B_le_D`, `Bounds.B_le_E`
* `Bounds.C_le_D`, `Bounds.C_le_E`
* `Bounds.C_eq_E_iff` : `C k = E k ↔ Even k`
* `Bounds.E_le_D` : `E k ≤ D k` for `k ∉ {1,3,5,7}`
* `Bounds.D_lt_E_exceptions` : `D k < E k` for `k ∈ {1,3,5,7}`

## Iterated (`r`-fold) comparisons (`RequestProject/Products.lean`)

* `Bounds.AA_le_BB`, `Bounds.AA_le_CC`, `Bounds.AA_le_DD`, `Bounds.AA_le_EE`
* `Bounds.BB_le_CC`, `Bounds.BB_le_DD`, `Bounds.BB_le_EE`
* `Bounds.CC_le_DD`, `Bounds.CC_le_EE`
* `Bounds.CC_eq_EE_iff` : `CC k r = EE k r` iff every `jᵢ` (`i<r`) is even
* `Bounds.EE_le_DD` : `EE k r ≤ DD k r` for all valid `(k,r) ∉ Exc`
* `Bounds.DD_lt_EE_exceptions` : `DD k r < EE k r` for the seven pairs in `Exc`
  `= {(3,1),(5,1),(5,2),(7,1),(9,2),(9,3),(17,4)}`.
-/
