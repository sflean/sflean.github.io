import RequestProject.SingleIndex

/-!
# Iterated (`r`-fold) comparisons `AA, BB, CC, DD, EE`

Along the chain `j₀ = k`, `j_{i+1} = hc (jᵢ)` we form the products
`AA k r = ∏_{i<r} A (jᵢ)`, and similarly `BB, CC, DD, EE`.

Because every single-index inequality holds for **all** indices, the corresponding
product inequalities hold for all `k, r`:

* `AA ≤ BB ≤ CC ≤ DD` and `AA ≤ BB ≤ CC ≤ EE`, `CC ≤ DD`, `CC ≤ EE`
  (hence also `AA ≤ DD`, `AA ≤ EE`, `BB ≤ DD`, `BB ≤ EE`).

The single pair whose direction is not settled factorwise is `DD` vs `EE`
(because `D j < E j` for `j ∈ {3,5,7}`).  The result is:

> For all `k, r` with `1 < jᵣ`, we have `EE k r ≤ DD k r`, **except** for the
> seven pairs `(k,r) ∈ {(3,1),(5,1),(5,2),(7,1),(9,2),(9,3),(17,4)}`,
> where `DD k r < EE k r`.
-/

open scoped BigOperators
open Finset

namespace Bounds

/-! ### Chain basics. -/

lemma chain_zero (k : ℕ) : chain k 0 = k := rfl

lemma chain_succ (k i : ℕ) : chain k (i + 1) = chain (hc k) i := by
  unfold chain; rw [Function.iterate_succ_apply]

lemma chain_succ' (k i : ℕ) : chain k (i + 1) = hc (chain k i) := by
  unfold chain; rw [Function.iterate_succ_apply']

lemma hc_mono {a b : ℕ} (h : a ≤ b) : hc a ≤ hc b := by unfold hc; omega

lemma chain_mono (r : ℕ) : ∀ {a b : ℕ}, a ≤ b → chain a r ≤ chain b r := by
  induction r with
  | zero => intro a b h; simpa using h
  | succ r ih => intro a b h; rw [chain_succ, chain_succ]; exact ih (hc_mono h)

lemma chain_step_le (k r : ℕ) : chain k (r + 1) ≤ chain k r := by
  rw [chain_succ']; exact hc_le_self _

lemma chain_antitone (k r d : ℕ) : chain k (r + d) ≤ chain k r := by
  induction d with
  | zero => simp
  | succ d ih =>
    calc chain k (r + (d + 1)) = chain k ((r + d) + 1) := by ring_nf
      _ ≤ chain k (r + d) := chain_step_le k (r + d)
      _ ≤ chain k r := ih

/-! ### First-term recursion for the products. -/

lemma AA_succ (k r : ℕ) : AA k (r + 1) = A k * AA (hc k) r := by
  unfold AA; rw [Finset.prod_range_succ']; simp only [chain_succ, chain_zero]; rw [mul_comm]

lemma BB_succ (k r : ℕ) : BB k (r + 1) = B k * BB (hc k) r := by
  unfold BB; rw [Finset.prod_range_succ']; simp only [chain_succ, chain_zero]; rw [mul_comm]

lemma CC_succ (k r : ℕ) : CC k (r + 1) = C k * CC (hc k) r := by
  unfold CC; rw [Finset.prod_range_succ']; simp only [chain_succ, chain_zero]; rw [mul_comm]

lemma DD_succ (k r : ℕ) : DD k (r + 1) = D k * DD (hc k) r := by
  unfold DD; rw [Finset.prod_range_succ']; simp only [chain_succ, chain_zero]; rw [mul_comm]

lemma EE_succ (k r : ℕ) : EE k (r + 1) = E k * EE (hc k) r := by
  unfold EE; rw [Finset.prod_range_succ']; simp only [chain_succ, chain_zero]; rw [mul_comm]

/-! ### The factorwise (always-true) product comparisons. -/

private lemma prod_chain_le {f g : ℕ → ℕ} (h : ∀ m, f m ≤ g m) (k r : ℕ) :
    (∏ i ∈ Finset.range r, f (chain k i)) ≤ ∏ i ∈ Finset.range r, g (chain k i) :=
  Finset.prod_le_prod' (fun i _ => h (chain k i))

theorem AA_le_BB (k r : ℕ) : AA k r ≤ BB k r := prod_chain_le A_le_B k r
theorem AA_le_CC (k r : ℕ) : AA k r ≤ CC k r := prod_chain_le A_le_C k r
theorem AA_le_DD (k r : ℕ) : AA k r ≤ DD k r := prod_chain_le A_le_D k r
theorem AA_le_EE (k r : ℕ) : AA k r ≤ EE k r := prod_chain_le A_le_E k r
theorem BB_le_CC (k r : ℕ) : BB k r ≤ CC k r := prod_chain_le B_le_C k r
theorem BB_le_DD (k r : ℕ) : BB k r ≤ DD k r := prod_chain_le B_le_D k r
theorem BB_le_EE (k r : ℕ) : BB k r ≤ EE k r := prod_chain_le B_le_E k r
theorem CC_le_DD (k r : ℕ) : CC k r ≤ DD k r := prod_chain_le C_le_D k r
theorem CC_le_EE (k r : ℕ) : CC k r ≤ EE k r := prod_chain_le C_le_E k r

/-- Cancellation helper: if `a ≤ b`, `c ≤ d`, `0 < c`, `0 < b` and `a*c = b*d`
then `a = b` and `c = d`. -/
private lemma mul_eq_mul_split {a b c d : ℕ} (hab : a ≤ b) (hcd : c ≤ d)
    (hc : 0 < c) (hb : 0 < b) (h : a * c = b * d) : a = b ∧ c = d := by
  have h1 : a * c ≤ b * c := Nat.mul_le_mul_right _ hab
  have h2 : b * c ≤ b * d := Nat.mul_le_mul_left _ hcd
  have hbc : b * c = a * c := by omega
  have hbd : b * c = b * d := by omega
  exact ⟨(Nat.eq_of_mul_eq_mul_right hc hbc).symm, Nat.eq_of_mul_eq_mul_left hb hbd⟩

/-- `CC k r = EE k r` iff every index `jᵢ` (`i < r`) is even. -/
theorem CC_eq_EE_iff (k r : ℕ) :
    CC k r = EE k r ↔ ∀ i ∈ Finset.range r, Even (chain k i) := by
  unfold CC EE
  induction r with
  | zero => simp
  | succ r ih =>
    rw [Finset.prod_range_succ, Finset.prod_range_succ, Finset.range_add_one,
        Finset.forall_mem_insert]
    have hle1 : (∏ i ∈ range r, C (chain k i)) ≤ ∏ i ∈ range r, E (chain k i) :=
      Finset.prod_le_prod' (fun i _ => C_le_E _)
    have hle2 : C (chain k r) ≤ E (chain k r) := C_le_E _
    have hProdpos : 0 < ∏ i ∈ range r, E (chain k i) := Finset.prod_pos (fun i _ => E_pos _)
    constructor
    · intro h
      obtain ⟨h1, h2⟩ := mul_eq_mul_split hle1 hle2 (C_pos _) hProdpos h
      exact ⟨(C_eq_E_iff _).mp h2, ih.mp h1⟩
    · rintro ⟨hlast, hrest⟩
      rw [ih.mpr hrest, (C_eq_E_iff _).mpr hlast]

/-! ### `DD` vs `EE`: the exceptional set. -/

/-- The seven exceptional pairs where `DD k r < EE k r`. -/
def Exc : Finset (ℕ × ℕ) := {(3, 1), (5, 1), (5, 2), (7, 1), (9, 2), (9, 3), (17, 4)}

/-- Bound on `r`: for `k ≤ 34`, validity `1 < jᵣ` forces `r ≤ 5`. -/
lemma r_bound {k r : ℕ} (hk : k ≤ 34) (hval : 1 < chain k r) : r ≤ 5 := by
  by_contra h
  push_neg at h
  have h1 : chain k r ≤ chain k 6 := by
    have := chain_antitone k 6 (r - 6)
    rwa [show 6 + (r - 6) = r by omega] at this
  have h2 : chain k 6 ≤ chain 34 6 := chain_mono 6 hk
  have h3 : chain 34 6 = 1 := by native_decide
  omega

/-- Finite base check: for `k ≤ 34` and `r ≤ 5`, if `(k,r)` is valid and not
exceptional then `EE k r ≤ DD k r`. -/
lemma base_check : ∀ k ∈ Finset.range 35, ∀ r ∈ Finset.range 6,
    1 < chain k r → (k, r) ∉ Exc → EE k r ≤ DD k r := by native_decide

/-- **Main `DD ≥ EE` theorem.** For every `k` and `r` with `1 < jᵣ`, we have
`EE k r ≤ DD k r`, unless `(k,r)` is one of the seven exceptional pairs. -/
theorem EE_le_DD (k r : ℕ) (hval : 1 < chain k r) (hne : (k, r) ∉ Exc) :
    EE k r ≤ DD k r := by
  revert r hval hne
  induction k using Nat.strong_induction_on with
  | _ k ih =>
    intro r hval hne
    rcases Nat.lt_or_ge k 35 with hk | hk
    · have hr : r ≤ 5 := r_bound (by omega) hval
      exact base_check k (Finset.mem_range.mpr (by omega)) r (Finset.mem_range.mpr (by omega)) hval hne
    · -- k ≥ 35
      cases r with
      | zero => simp [EE, DD]
      | succ r =>
        rw [EE_succ, DD_succ]
        have hmk : hc k < k := by unfold hc; omega
        have hval' : 1 < chain (hc k) r := by rw [← chain_succ]; exact hval
        have hnotexc : (hc k, r) ∉ Exc := by
          intro hmem
          simp only [Exc, Finset.mem_insert, Finset.mem_singleton, Prod.mk.injEq] at hmem
          unfold hc at hmem
          omega
        have ihm := ih (hc k) hmk r hval' hnotexc
        have hED : E k ≤ D k := E_le_D (by omega) (by omega) (by omega) (by omega)
        exact Nat.mul_le_mul hED ihm

/-- The seven genuine exceptions: `DD k r < EE k r`. -/
theorem DD_lt_EE_exceptions :
    DD 3 1 < EE 3 1 ∧ DD 5 1 < EE 5 1 ∧ DD 5 2 < EE 5 2 ∧ DD 7 1 < EE 7 1 ∧
    DD 9 2 < EE 9 2 ∧ DD 9 3 < EE 9 3 ∧ DD 17 4 < EE 17 4 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> native_decide

/-! ### Transitive corollaries for the products. -/

theorem AA_le_DD' (k r : ℕ) : AA k r ≤ DD k r := AA_le_DD k r
theorem BB_le_DD' (k r : ℕ) : BB k r ≤ DD k r := BB_le_DD k r

end Bounds
