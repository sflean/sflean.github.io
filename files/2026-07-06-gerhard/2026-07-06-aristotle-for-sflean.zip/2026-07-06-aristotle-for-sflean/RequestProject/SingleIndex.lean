import RequestProject.Defs

/-!
# Single-index comparisons between `A, B, C, D, E`

The complete picture (proved below) is, for every `k`:

* `A k ≤ B k ≤ C k ≤ D k`,
* `C k ≤ E k`, with equality iff `k` is even,
* `E k ≤ D k` for all `k` except `k ∈ {1,3,5,7}` (where `D k < E k`).

Consequently `A k ≤ D k`, `A k ≤ E k`, `B k ≤ D k`, `B k ≤ E k`.
-/

open scoped BigOperators
open Finset

namespace Bounds

/-! ### Basic arithmetic facts about `hc` and positivity. -/

lemma hc_le_self (k : ℕ) : hc k ≤ k := by unfold hc; omega

lemma le_two_mul_hc (k : ℕ) : k ≤ 2 * hc k := by unfold hc; omega

lemma sub_hc_le_hc (k : ℕ) : k - hc k ≤ hc k := by unfold hc; omega

lemma C_pos (k : ℕ) : 0 < C k := by
  unfold C; exact Nat.choose_pos (by unfold hc; omega)

lemma D_pos (k : ℕ) : 0 < D k := by unfold D; positivity

lemma E_pos (k : ℕ) : 0 < E k := by
  unfold E; exact Nat.choose_pos (by omega)

lemma A_pos (k : ℕ) : 0 < A k := by
  unfold A; apply Finset.prod_pos; intro p hp
  simp only [Aset, Finset.mem_filter] at hp
  exact hp.2.pos

lemma B_pos (k : ℕ) : 0 < B k := by
  unfold B; apply Finset.prod_pos; intro p hp
  simp only [Bset, Finset.mem_filter, Bpred] at hp
  exact hp.2.1.pos

/-! ### Divisibility facts driving `A ≤ C` and `B ≤ C`. -/

/-- Each prime `p` contributing to `A k` divides `C k = C(k, ⌈k/2⌉)`. -/
lemma prime_dvd_C_of_mem_Aset {k p : ℕ} (hp : p ∈ Aset k) : p ∣ C k := by
  simp only [Aset, Finset.mem_filter, Finset.mem_Ioc] at hp
  obtain ⟨⟨hlt, hle⟩, hpr⟩ := hp
  unfold C
  exact hpr.dvd_choose (by omega) (by have := sub_hc_le_hc k; omega) hle

/-- `A k` divides `C k`. -/
lemma A_dvd_C (k : ℕ) : A k ∣ C k := by
  unfold A
  apply Finset.prod_primes_dvd
  · intro a ha
    simp only [Aset, Finset.mem_filter] at ha
    exact ha.2.prime
  · intro a ha
    exact prime_dvd_C_of_mem_Aset ha

/-
Each prime `p` contributing to `B k` divides `C k`.

The key number-theoretic fact: if some power `p^e` (`e ≥ 1`) satisfies `hc k < p^e ≤ k`,
then `p` divides `C(k, hc k)` (there is a carry at position `e` when adding `hc k` and
`k - hc k` in base `p`).
-/
lemma prime_dvd_C_of_mem_Bset {k p : ℕ} (hp : p ∈ Bset k) : p ∣ C k := by
  -- From `p ∈ Bset k` (unfold `Bset`, `Finset.mem_filter`, `Bpred`), extract: `p` is prime (`hpr : Nat.Prime p`), and there exist `e` with `e ∈ Finset.Icc 1 k`, `hc k < p ^ e`, and `p ^ e ≤ k`.
  unfold Bset at hp
  simp at hp
  obtain ⟨hpr, e, he⟩ := hp;
  obtain ⟨ e, he₁, he₂, he₃ ⟩ := he; simp_all +decide ;
  -- To compute the factorization, apply `Nat.factorization_choose hpr hkn (hnb : Nat.log p k < b)` with `b := k + 1`.
  have h_factorization : (Nat.factorization (Nat.choose k (hc k))) p = Finset.card (Finset.filter (fun i => p ^ i ≤ (hc k) % p ^ i + (k - hc k) % p ^ i) (Finset.Ico 1 (k + 1))) := by
    convert Nat.factorization_choose ‹Nat.Prime p› _ _ using 1;
    · exact hc_le_self k;
    · exact Nat.lt_succ_of_le ( Nat.log_le_self _ _ );
  -- Show that the element `e` is in the filtered finset.
  have h_mem : e ∈ Finset.filter (fun i => p ^ i ≤ (hc k) % p ^ i + (k - hc k) % p ^ i) (Finset.Ico 1 (k + 1)) := by
    simp_all +decide [ Nat.mod_eq_of_lt ];
    rw [ Nat.mod_eq_of_lt ] <;> linarith [ Nat.sub_add_cancel ( show hc k ≤ k from hc_le_self k ), sub_hc_le_hc k ];
  exact Nat.Prime.dvd_iff_one_le_factorization ( by assumption ) ( Nat.ne_of_gt ( C_pos k ) ) |>.2 ( h_factorization.symm ▸ Finset.card_pos.mpr ⟨ e, h_mem ⟩ )

/-- `B k` divides `C k`. -/
lemma B_dvd_C (k : ℕ) : B k ∣ C k := by
  unfold B
  apply Finset.prod_primes_dvd
  · intro a ha
    simp only [Bset, Finset.mem_filter, Bpred] at ha
    exact ha.2.1.prime
  · intro a ha
    exact prime_dvd_C_of_mem_Bset ha

/-! ### The main single-index comparisons. -/

/-- `A k ≤ B k` (the index set of `A` is contained in that of `B`). -/
theorem A_le_B (k : ℕ) : A k ≤ B k := by
  unfold A B
  apply Finset.prod_le_prod_of_subset_of_one_le'
  · intro p hp
    simp only [Aset, Finset.mem_filter, Finset.mem_Ioc] at hp
    simp only [Bset, Finset.mem_filter, Finset.mem_range, Bpred]
    obtain ⟨⟨h1, h2⟩, hpr⟩ := hp
    refine ⟨by omega, hpr, 1, ?_, ?_, ?_⟩
    · simp only [Finset.mem_Icc]; exact ⟨le_refl 1, by omega⟩
    · simpa using h1
    · simpa using h2
  · intro p hp _
    simp only [Bset, Finset.mem_filter, Finset.mem_range, Bpred] at hp
    exact hp.2.1.one_lt.le

/-- `A k ≤ C k`. -/
theorem A_le_C (k : ℕ) : A k ≤ C k := Nat.le_of_dvd (C_pos k) (A_dvd_C k)

/-- `B k ≤ C k`. -/
theorem B_le_C (k : ℕ) : B k ≤ C k := Nat.le_of_dvd (C_pos k) (B_dvd_C k)

/-- `C k ≤ D k` (central binomial coefficient bounded by `4^⌊k/2⌋`). -/
theorem C_le_D (k : ℕ) : C k ≤ D k := by
  unfold C D
  have hsymm : k.choose (hc k) = k.choose (k - hc k) := (Nat.choose_symm (hc_le_self k)).symm
  rw [hsymm]
  calc k.choose (k - hc k) ≤ (2 * (k - hc k) + 1).choose (k - hc k) :=
        Nat.choose_le_choose _ (by unfold hc; omega)
    _ ≤ 4 ^ (k - hc k) := Nat.choose_middle_le_pow _

/-- `C k ≤ E k` (monotonicity of binomial coefficients since `k ≤ 2⌈k/2⌉`). -/
theorem C_le_E (k : ℕ) : C k ≤ E k := by
  unfold C E; exact Nat.choose_le_choose _ (le_two_mul_hc k)

/-- For even `k`, `C k = E k` (because `k = 2⌈k/2⌉`). -/
theorem C_eq_E_of_even {k : ℕ} (hk : Even k) : C k = E k := by
  unfold C E
  have : 2 * hc k = k := by unfold hc; rw [Nat.even_iff] at hk; omega
  rw [this]

/-- For odd `k`, `C k < E k`. -/
theorem C_lt_E_of_odd {k : ℕ} (hk : Odd k) : C k < E k := by
  unfold C E
  have hkpos : 1 ≤ k := hk.pos
  have h1 : 2 * hc k = k + 1 := by unfold hc; rw [Nat.odd_iff] at hk; omega
  rw [h1]
  obtain ⟨j, hj⟩ : ∃ j, hc k = j + 1 := ⟨hc k - 1, by unfold hc; omega⟩
  rw [hj, Nat.choose_succ_succ k j]
  have hpos : 0 < k.choose j := Nat.choose_pos (by have := hc_le_self k; omega)
  have : k.choose j.succ = k.choose (j + 1) := rfl
  omega

/-- `C k = E k` iff `k` is even. -/
theorem C_eq_E_iff (k : ℕ) : C k = E k ↔ Even k := by
  refine ⟨fun h => ?_, C_eq_E_of_even⟩
  rcases Nat.even_or_odd k with he | ho
  · exact he
  · exact absurd h (ne_of_lt (C_lt_E_of_odd ho))

/-! ### `E ≤ D` with the four exceptions `k ∈ {1,3,5,7}`. -/

/-- The plain central binomial bound `C(2m, m) ≤ 4^m`. -/
lemma cb_le_four_pow (m : ℕ) : Nat.centralBinom m ≤ 4 ^ m := by
  rw [Nat.centralBinom_eq_two_mul_choose]
  calc (2 * m).choose m ≤ (2 * m + 1).choose m := Nat.choose_le_choose _ (by omega)
    _ ≤ 4 ^ m := Nat.choose_middle_le_pow m

/-- Central binomial bound `C(2n, n) ≤ 4^(n-1)` for `n ≥ 5`, proved by induction. -/
lemma centralBinom_le_four_pow_pred (n : ℕ) (hn : 5 ≤ n) :
    Nat.centralBinom n ≤ 4 ^ (n - 1) := by
  induction n with
  | zero => omega
  | succ m ih =>
    rcases Nat.lt_or_ge m 5 with hm | hm
    · have : m = 4 := by omega
      subst this; native_decide
    · have ihm := ih hm
      have hrec := Nat.succ_mul_centralBinom_succ m
      have hmpos : 0 < m + 1 := by omega
      have key : (m + 1) * Nat.centralBinom (m + 1) ≤ (m + 1) * 4 ^ m := by
        rw [hrec]
        calc 2 * (2 * m + 1) * Nat.centralBinom m ≤ 2 * (2 * m + 1) * 4 ^ (m - 1) :=
              Nat.mul_le_mul_left _ ihm
          _ ≤ (m + 1) * 4 ^ m := by
              have h4 : 4 ^ m = 4 * 4 ^ (m - 1) := by rw [← pow_succ']; congr 1; omega
              rw [h4]
              nlinarith [Nat.one_le_iff_ne_zero.mpr (pow_ne_zero (m - 1) (by norm_num : (4 : ℕ) ≠ 0))]
      have : Nat.centralBinom (m + 1) ≤ 4 ^ m := le_of_mul_le_mul_left key hmpos
      simpa using this

/-- `E k ≤ D k` for all `k ∉ {1,3,5,7}`. -/
theorem E_le_D {k : ℕ} (h1 : k ≠ 1) (h3 : k ≠ 3) (h5 : k ≠ 5) (h7 : k ≠ 7) :
    E k ≤ D k := by
  unfold E D
  rcases Nat.even_or_odd k with he | ho
  · have hsub : k - hc k = hc k := by unfold hc; rw [Nat.even_iff] at he; omega
    rw [hsub]
    have := cb_le_four_pow (hc k)
    rwa [Nat.centralBinom_eq_two_mul_choose] at this
  · have hodd : k % 2 = 1 := Nat.odd_iff.mp ho
    have hk9 : 9 ≤ k := by rcases ho with ⟨m, rfl⟩; omega
    have hh : 2 * hc k = k + 1 := by unfold hc; omega
    have hsub : k - hc k = hc k - 1 := by unfold hc; omega
    have h5le : 5 ≤ hc k := by unfold hc; omega
    rw [hsub, hh]
    have := centralBinom_le_four_pow_pred (hc k) h5le
    rwa [Nat.centralBinom_eq_two_mul_choose, hh] at this

/-- The four genuine exceptions: `D k < E k` for `k ∈ {1,3,5,7}`. -/
theorem D_lt_E_exceptions : D 1 < E 1 ∧ D 3 < E 3 ∧ D 5 < E 5 ∧ D 7 < E 7 := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;> · unfold D E hc; norm_num [Nat.choose]

/-! ### Transitive corollaries. -/

theorem A_le_D (k : ℕ) : A k ≤ D k := (A_le_C k).trans (C_le_D k)
theorem A_le_E (k : ℕ) : A k ≤ E k := (A_le_C k).trans (C_le_E k)
theorem B_le_D (k : ℕ) : B k ≤ D k := (B_le_C k).trans (C_le_D k)
theorem B_le_E (k : ℕ) : B k ≤ E k := (B_le_C k).trans (C_le_E k)

end Bounds